//
//  AppDelegate.h
//  Radio
//
//  Created by Om Prakash on 18/08/14.
//  Copyright (c) 2014 Octal Info Solution. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RadioViewController.h"
#import "AllarmViewController.h"
#import "TwitterViewController.h"
#import "FacebookViewController.h"
#import "MoreViewController.h"


@interface AppDelegate : UIResponder <UIApplicationDelegate,UITabBarControllerDelegate>{
    
    UIButton *btn_listen,*btn_alarm,*btn_facebook,*btn_twitter,*btn_more;
    UIBackgroundTaskIdentifier counterTask;
    
}

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic)UINavigationController *nav;
@property (strong, nonatomic) UINavigationController *navigationClassReference;
@property (strong, nonatomic)RadioViewController    *radio;
@property (strong, nonatomic)AllarmViewController   *allarm;
@property (strong, nonatomic)TwitterViewController  *twitter;
@property (strong, nonatomic)FacebookViewController *facebook;
@property (strong, nonatomic)MoreViewController     *more;

@property (assign, nonatomic) int appType;
@property (strong, nonatomic) UIView                *viewToolBarBase;
@property (strong, nonatomic) UITabBarController    *tabBarController;


-(IBAction)btnListenPressed:(id)sender;
-(IBAction)btnAlarmPressed:(id)sender;
-(IBAction)btnFacebookPressed:(id)sender;
-(IBAction)btnTwitterPressed:(id)sender;
-(IBAction)btnMorePressed:(id)sender;


+(AppDelegate *)sharedAppDelegate;

-(void)createTabBar;
-(void)removeTabBar;

@end
