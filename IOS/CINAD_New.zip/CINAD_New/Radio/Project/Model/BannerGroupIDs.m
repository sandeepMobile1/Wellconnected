//
//  BannerGroupIDs.m
//  Radio
//
//  Created by Om Prakash on 20/08/14.
//  Copyright (c) 2014 Octal Info Solution. All rights reserved.
//

#import "BannerGroupIDs.h"

@implementation BannerGroupIDs
@synthesize image;
@synthesize url;
@end
