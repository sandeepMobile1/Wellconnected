//
//  BaseUrlModel.m
//  Radio
//
//  Created by Om Prakash on 19/08/14.
//  Copyright (c) 2014 Octal Info Solution. All rights reserved.
//

#import "BaseUrlModel.h"

@implementation BaseUrlModel
@synthesize title;
@synthesize vortalCallLetters;
@synthesize vortatStationId;
@synthesize websiteUrl;
@synthesize facebook;
@synthesize twitter;
@synthesize uploadurl;
@synthesize fgUrl;
@synthesize iosStreamUrl;
@synthesize bannerGroupId;
@synthesize headerImage;
@synthesize signupUrl;
@synthesize infoUrl;
@synthesize stationid;
@synthesize photocontentid;
@synthesize videocontentid;
@synthesize termsofuse;
@end
