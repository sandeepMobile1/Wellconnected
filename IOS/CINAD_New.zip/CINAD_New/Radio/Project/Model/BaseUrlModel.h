//
//  BaseUrlModel.h
//  Radio
//
//  Created by Om Prakash on 19/08/14.
//  Copyright (c) 2014 Octal Info Solution. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BaseUrlModel : NSObject

@property(nonatomic, strong)NSString *title;
@property(nonatomic, strong)NSString *vortalCallLetters;
@property(nonatomic, strong)NSString *vortatStationId;
@property(nonatomic, strong)NSString *websiteUrl;
@property(nonatomic, strong)NSString *facebook;
@property(nonatomic, strong)NSString *twitter;
@property(nonatomic, strong)NSString *uploadurl;
@property(nonatomic, strong)NSString *fgUrl;
@property(nonatomic, strong)NSString *iosStreamUrl;
@property(nonatomic, strong)NSString *bannerGroupId;
@property(nonatomic, strong)NSString *headerImage;
@property(nonatomic, strong)NSString *signupUrl;
@property(nonatomic, strong)NSString *infoUrl;
@property(nonatomic, strong)NSString *stationid;
@property(nonatomic, strong)NSString *photocontentid;
@property(nonatomic, strong)NSString *videocontentid;
@property(nonatomic, strong)NSString *termsofuse;

@end
