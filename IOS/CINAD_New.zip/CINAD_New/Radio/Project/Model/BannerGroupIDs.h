//
//  BannerGroupIDs.h
//  Radio
//
//  Created by Om Prakash on 20/08/14.
//  Copyright (c) 2014 Octal Info Solution. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BannerGroupIDs : NSObject
@property(nonatomic, strong)NSString *image;
@property(nonatomic, strong)NSString *url;
@end
