//
//  StreetFormModel.m
//  Radio
//
//  Created by Om Prakash on 21/08/14.
//  Copyright (c) 2014 Octal Info Solution. All rights reserved.
//

#import "StreetFormModel.h"

@implementation StreetFormModel
@synthesize fname;
@synthesize lname;
@synthesize gender;
@synthesize isAgree;

@end
