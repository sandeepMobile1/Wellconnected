//
//  AllarmViewController.h
//  Radio
//
//  Created by Om Prakash on 18/08/14.
//  Copyright (c) 2014 Octal Info Solution. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseUrlModel.h"

@interface AllarmViewController : UIViewController{
    IBOutlet UIImageView *headerImageView;
    IBOutlet UILabel *lblRedText;
    IBOutlet UILabel *lblYellowText;
    
    BaseUrlModel *model;
    
    IBOutlet UIDatePicker *date_picker;
    IBOutlet UISwitch *switch_mode;
    
    IBOutlet UIView *view_alarm;
    
    IBOutlet UIScrollView *scroll;

}

-(IBAction)getDateSelection:(id)sender;
-(IBAction)switchVlaueChanges:(id)sender;

@end
