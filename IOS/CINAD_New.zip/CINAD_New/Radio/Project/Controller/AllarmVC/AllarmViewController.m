//
//  AllarmViewController.m
//  Radio
//
//  Created by Om Prakash on 18/08/14.
//  Copyright (c) 2014 Octal Info Solution. All rights reserved.
//

#import "AllarmViewController.h"

@interface AllarmViewController ()

@end

@implementation AllarmViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    model = (BaseUrlModel *)[AppSetting getBaseUrlSetting];
    
    scroll.scrollEnabled = FALSE;
    
    NSString *img = model.headerImage;
    
    [headerImageView setImageWithURL:[NSURL URLWithString:!([img isEqual:(NSString*)[NSNull null]])? img:@""] placeholderImage:[UIImage imageNamed:@"thumnail_img_hover.png"]];
    
    

    
    scroll.scrollEnabled = FALSE;

    

    if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0")){
        
        if(IS_IPHONE_5){
            
            headerImageView.frame = CGRectMake(0, 0, headerImageView.frame.size.width, headerImageView.frame.size.height);
            view_alarm.frame = CGRectMake(0, headerImageView.frame.size.height, view_alarm.frame.size.width, view_alarm.frame.size.height);
            
        }
        else{
            [scroll setContentSize:CGSizeMake(320, 568)];
            
            headerImageView.frame = CGRectMake(0, 0, headerImageView.frame.size.width, headerImageView.frame.size.height);
            view_alarm.frame = CGRectMake(0, headerImageView.frame.size.height, view_alarm.frame.size.width, view_alarm.frame.size.height);
            
            switch_mode.frame = CGRectMake(switch_mode.frame.origin.x, switch_mode.frame.origin.y-3, switch_mode.frame.size.width, switch_mode.frame.size.height);
            
        }
    }
    else{
        if(IS_IPHONE_5){
            headerImageView.frame = CGRectMake(0, 0, headerImageView.frame.size.width, headerImageView.frame.size.height);
            view_alarm.frame = CGRectMake(0, headerImageView.frame.size.height, view_alarm.frame.size.width, view_alarm.frame.size.height);
        }
        else{
            
            [scroll setContentSize:CGSizeMake(320, 600)];

            headerImageView.frame = CGRectMake(0, 0, headerImageView.frame.size.width, headerImageView.frame.size.height);
            view_alarm.frame = CGRectMake(0, headerImageView.frame.size.height, view_alarm.frame.size.width, view_alarm.frame.size.height);
        }
    }

}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    
    if([AppSetting isAlarm]){
        switch_mode.on = TRUE;
    }
    else{
        switch_mode.on = FALSE;
    }
    

}

#pragma  mark - Date Picker Action
-(IBAction)getDateSelection:(id)sender{
    
    NSDate *pickerDate = [date_picker date];
    
    // Schedule the notification
    UILocalNotification* localNotification = [[UILocalNotification alloc] init];
    localNotification.fireDate = pickerDate;
    localNotification.alertBody = @"Play FM";
    localNotification.alertAction = @"Play FM";
    localNotification.timeZone = [NSTimeZone defaultTimeZone];
    
    [[UIApplication sharedApplication] scheduleLocalNotification:localNotification];
    
}

#pragma  mark - Switch Action

-(IBAction)switchVlaueChanges:(id)sender{
    UISwitch *sw=(UISwitch*)sender;
    NSString *status = [NSString stringWithFormat:@"%d",sw.on];
    
    
    NSString *state;
    if(sw.on){
        state = @"1";
        [AppSetting setAlarm:YES];
    }
    else{
        state = @"0";
        
        [AppSetting setAlarm:NO];
    }
    
    
    NSLog(@"status = %@",status);
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
