//
//  SignUpViewController.h
//  Radio
//
//  Created by Om Prakash on 20/08/14.
//  Copyright (c) 2014 Octal Info Solution. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseUrlModel.h"

@interface SignUpViewController : UIViewController<UIWebViewDelegate>{
    IBOutlet UIWebView *signUp_web;
    BaseUrlModel *model;
}


@end
