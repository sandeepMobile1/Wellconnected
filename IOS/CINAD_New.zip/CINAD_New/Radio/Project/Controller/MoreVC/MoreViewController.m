//
//  MoreViewController.m
//  Radio
//
//  Created by Om Prakash on 18/08/14.
//  Copyright (c) 2014 Octal Info Solution. All rights reserved.
//

#import "MoreViewController.h"
#import "MoreTableViewCell.h"
#import "WebSiteViewController.h"
#import "SignUpViewController.h"
#import "InfoPageViewController.h"
#import "StreetTeamViewController.h"


#define ARR_TABLE_TITLE [NSArray arrayWithObjects:@"Website",@"Info page",@"Sign up",@"Street Team", nil]
#define ARR_TABLE_ICON_IMG [NSArray arrayWithObjects:@"Website",@"Info page",@"Signup",@"StreetTeam", nil]

@interface MoreViewController ()

@end

@implementation MoreViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    UILabel *lblTitle = getLabel(CGRectMake(0, 0, 100, 44), @"More", [UIColor whiteColor], TitleFontStyle, 24);
    
    self.navigationItem.titleView=lblTitle;

    
    [tbl_more setBackgroundColor:[UIColor clearColor]];
    
    [tbl_more setSeparatorColor:nil];
    [tbl_more setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    
    
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0")){
        self.navigationController.navigationBar.barTintColor = MoreNavColor;
    }
    else{
        self.navigationController.navigationBar.tintColor = MoreNavColor;
    }
}

#pragma mark -
#pragma mark - UITableViewDelegate

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 45;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return [ARR_TABLE_TITLE count];
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *RowIdentifier = @"rowIdentifierCall";
    MoreTableViewCell *Cell=[tableView dequeueReusableCellWithIdentifier:RowIdentifier];
    if(Cell == nil)
    {
        NSArray *customCells = [[NSBundle mainBundle] loadNibNamed:@"MoreTableViewCell" owner:self options:nil];
        Cell = [customCells objectAtIndex:0];
        Cell.accessoryType = UITableViewCellAccessoryNone;
        Cell.selectionStyle=UITableViewCellSelectionStyleNone;
    }
    
    Cell.lbl_title.text = [ARR_TABLE_TITLE objectAtIndex:indexPath.row];
    
    return Cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if(indexPath.row == 0){
        WebSiteViewController *website = [[WebSiteViewController alloc]init];
        [self.navigationController pushViewController:website animated:YES];
    }
    else if(indexPath.row == 1){
        InfoPageViewController *info = [[InfoPageViewController alloc]init];
        [self.navigationController pushViewController:info animated:YES];
    }
    else if(indexPath.row == 2){
        SignUpViewController *signUp = [[SignUpViewController alloc]init];
        [self.navigationController pushViewController:signUp animated:YES];
    }
    else if(indexPath.row == 3){
        StreetTeamViewController *street = [[StreetTeamViewController alloc]init];
        [self.navigationController pushViewController:street animated:YES];
    }

}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
