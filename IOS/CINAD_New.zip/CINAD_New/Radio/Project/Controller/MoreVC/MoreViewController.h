//
//  MoreViewController.h
//  Radio
//
//  Created by Om Prakash on 18/08/14.
//  Copyright (c) 2014 Octal Info Solution. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MoreViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>{
    IBOutlet UITableView *tbl_more;
}

@end
