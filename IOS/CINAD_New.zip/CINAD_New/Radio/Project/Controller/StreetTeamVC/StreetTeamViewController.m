//
//  StreetTeamViewController.m
//  Radio
//
//  Created by Om Prakash on 18/08/14.
//  Copyright (c) 2014 Octal Info Solution. All rights reserved.
//

#import "StreetTeamViewController.h"
#import "UIImageExtras.h"
#import "QSUtilities.h"
#import "ASIFormDataRequest.h"

#define ARR_GENDER [NSArray arrayWithObjects:@"Male",@"Female", nil]


@interface StreetTeamViewController (Private)<UpLoadMediaInvocationDelegate>

@end

@implementation StreetTeamViewController
@synthesize keyboardControls;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    model = (BaseUrlModel *)[AppSetting getBaseUrlSetting];
    
    UILabel *lblTitle = getLabel(CGRectMake(0, 0, 100, 44), model.title, [UIColor whiteColor], TitleFontStyle, 24);
    
    self.navigationItem.titleView=lblTitle;
    
    if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0")){
        self.navigationController.navigationBar.barTintColor = StreetNavColor;
    }
    else{
        self.navigationController.navigationBar.tintColor = StreetNavColor;
    }
    
    UIButton *backButton=getButtonImage(CGRectMake(0, 0, 24, 24), @"back.png", self, @selector(btnBackPressed:));
    UIBarButtonItem *leftBtn=[[UIBarButtonItem alloc]initWithCustomView:backButton];
    self.navigationItem.leftBarButtonItem=leftBtn;
    
    
    
    if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0")){
        
        if(IS_IPHONE_5){
            
            [scroll setContentSize:CGSizeMake(320, 650)];

            
            view_appSetting.frame = CGRectMake(view_appSetting.frame.origin.x, 64, view_appSetting.frame.size.width, view_appSetting.frame.size.height)
            ;
        }
        else{
            
            
            view_appSetting.frame = CGRectMake(view_appSetting.frame.origin.x, 64, view_appSetting.frame.size.width, view_appSetting.frame.size.height);
            
            [scroll setContentSize:CGSizeMake(320, 650)];
            
            bg_imgView.frame = CGRectMake(bg_imgView.frame.origin.x, bg_imgView.frame.origin.y, bg_imgView.frame.size.width, bg_imgView.frame.size.height);
            
            btn_take_picture.frame = CGRectMake(btn_take_picture.frame.origin.x, btn_take_picture.frame.origin.y-20, btn_take_picture.frame.size.width, btn_take_picture.frame.size.height);
            
            btn_take_video.frame = CGRectMake(btn_take_video.frame.origin.x, btn_take_video.frame.origin.y-20, btn_take_video.frame.size.width, btn_take_video.frame.size.height);
            
            btn_gallary.frame = CGRectMake(btn_gallary.frame.origin.x, btn_gallary.frame.origin.y-20, btn_gallary.frame.size.width, btn_gallary.frame.size.height);

        }
        
    }
    else{
        if(IS_IPHONE_5){
            
            [scroll setContentSize:CGSizeMake(320, 650)];

            
            view_appSetting.frame = CGRectMake(view_appSetting.frame.origin.x, 0, view_appSetting.frame.size.width, view_appSetting.frame.size.height);
            
            bg_imgView.frame = CGRectMake(bg_imgView.frame.origin.x, bg_imgView.frame.origin.y-50, bg_imgView.frame.size.width, bg_imgView.frame.size.height);
            
            btn_take_picture.frame = CGRectMake(btn_take_picture.frame.origin.x, btn_take_picture.frame.origin.y-50, btn_take_picture.frame.size.width, btn_take_picture.frame.size.height);
            
            btn_take_video.frame = CGRectMake(btn_take_video.frame.origin.x, btn_take_video.frame.origin.y-50, btn_take_video.frame.size.width, btn_take_video.frame.size.height);
            
            btn_gallary.frame = CGRectMake(btn_gallary.frame.origin.x, btn_gallary.frame.origin.y-50, btn_gallary.frame.size.width, btn_gallary.frame.size.height);
            
        }
        else{
            
            [scroll setContentSize:CGSizeMake(320, 650)];
            
            
            view_appSetting.frame = CGRectMake(view_appSetting.frame.origin.x, 0, view_appSetting.frame.size.width, view_appSetting.frame.size.height);

            bg_imgView.frame = CGRectMake(bg_imgView.frame.origin.x, bg_imgView.frame.origin.y-50, bg_imgView.frame.size.width, bg_imgView.frame.size.height);
            
            btn_take_picture.frame = CGRectMake(btn_take_picture.frame.origin.x, btn_take_picture.frame.origin.y-90, btn_take_picture.frame.size.width, btn_take_picture.frame.size.height);
            
            btn_take_video.frame = CGRectMake(btn_take_video.frame.origin.x, btn_take_video.frame.origin.y-90, btn_take_video.frame.size.width, btn_take_video.frame.size.height);
            
            btn_gallary.frame = CGRectMake(btn_gallary.frame.origin.x, btn_gallary.frame.origin.y-90, btn_gallary.frame.size.width, btn_gallary.frame.size.height);
        }
    }

    for (UITextField *subVw in scroll.subviews) {
        if ([subVw isKindOfClass:[UITextField class]]) {
            
            [subVw setValue:[UIFont fontWithName:ARIALFONT size:16.0] forKeyPath:@"_placeholderLabel.font"];
            
            
            [subVw setValue:[UIColor colorWithRed:154/255.0 green:156/255.0 blue:158/255.0 alpha:1.0] forKeyPath:@"_placeholderLabel.textColor"];
            
        }
    }
    
    view_picker.frame = CGRectMake(0, self.view.bounds.size.height, 320, 162);
    [self.view addSubview:view_picker];
    
    [self addKeyboardControls];


}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    
    model = nil;
    model = (BaseUrlModel *)[AppSetting getBaseUrlSetting];

    
    if([AppSetting getIsAgree]){
        [btn_agree setImage:[UIImage imageNamed:@"checked"] forState:UIControlStateNormal];
    }
    else{
        [btn_agree setImage:[UIImage imageNamed:@"check"] forState:UIControlStateNormal];
    }
    
    NSString *str_fname = [AppSetting getFirstName];
    NSString *str_lname = [AppSetting getLarstName];
    NSString *str_bday = [AppSetting getBdayYear];
    NSString *str_gender = [AppSetting getGender];
    
    if([str_gender length]==0){
        str_gender = @"Select your gender";
    }
    
    
    BOOL isAgree = [AppSetting getIsAgree];
    
    
    txt_fname.text = str_fname;
    txt_lname.text = str_lname;
    txt_bday.text = str_bday;
    lbl_gender.text = str_gender;
    
    
    if([str_fname length] == 0 || [str_lname length] == 0 || [str_bday length] == 0 || [str_gender isEqualToString:@"Select your gender"] || !isAgree){
        view_appSetting.hidden = FALSE;
    }
    else{
        view_appSetting.hidden = TRUE;
    }
    
    [self.view addSubview:view_captionEpi];
    view_captionEpi.hidden = TRUE;
    
    if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0")){
        
        if(IS_IPHONE_5){
            view_captionEpi.frame = CGRectMake(view_captionEpi.frame.origin.x, 84, view_captionEpi.frame.size.width, view_captionEpi.frame.size.height);
        }
        else{
            
            view_captionEpi.frame = CGRectMake(view_captionEpi.frame.origin.x, 84, view_captionEpi.frame.size.width, view_captionEpi.frame.size.height);
        }
        
    }
    else{
        if(IS_IPHONE_5){
            view_captionEpi.frame = CGRectMake(view_captionEpi.frame.origin.x, 20, view_captionEpi.frame.size.width, view_captionEpi.frame.size.height);
        }
        else{
            view_captionEpi.frame = CGRectMake(view_captionEpi.frame.origin.x, 20, view_captionEpi.frame.size.width, view_captionEpi.frame.size.height);
        }
    }

    

    
}

-(IBAction)btn_form_submit:(id)sender{
    
    NSString *str_fname = [AppSetting getFirstName];
    NSString *str_lname = [AppSetting getLarstName];
    NSString *str_bday = [AppSetting getBdayYear];
    NSString *str_gender = [AppSetting getGender];
    
    BOOL isAgree = [AppSetting getIsAgree];

    
    if([str_fname length] == 0 || [str_lname length] == 0 || [str_bday length] == 0 || [str_gender isEqualToString:@"Select your gender"]){
        
        [Utils showAlertMessage:@"" Message:@"Please fill all fields."];
        
    }
    else if(!isAgree){
        [Utils showAlertMessage:@"" Message:@"Please check the agree button."];

    }
    else{
        view_appSetting.hidden = TRUE;
    }}


-(IBAction)btn_agre_pressed:(id)sender{
    if([AppSetting getIsAgree]){
        [btn_agree setImage:[UIImage imageNamed:@"check"] forState:UIControlStateNormal];
        [AppSetting setIsAgree:NO];
    }
    else{
        [AppSetting setIsAgree:YES];
        [btn_agree setImage:[UIImage imageNamed:@"checked"] forState:UIControlStateNormal];
    }
}

-(IBAction)showTermView:(id)sender{
    
    NSLog(@"Model.TermofUse = %@",model.termsofuse);
    
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:model.termsofuse]];

    
/*    [self.view addSubview:view_term];
    view_term.hidden = FALSE;
    
    if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0")){
        
            view_term.frame = CGRectMake(view_term.frame.origin.x, 64, view_term.frame.size.width, view_term.frame.size.height);
        
    }
    else{
            view_term.frame = CGRectMake(view_term.frame.origin.x, 0, view_term.frame.size.width, view_term.frame.size.height);
    } */
}

-(IBAction)closeTermView:(id)sender{
    view_term.hidden = TRUE;
    
}

-(IBAction)btnBackPressed:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)btn_gender_pressed:(id)sender{
    
    
    txt_bday.enabled = FALSE;
    txt_fname.enabled = FALSE;
    txt_lname.enabled = FALSE;
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0")){
        view_picker.frame = CGRectMake(0, self.view.bounds.size.height-212, 320, 162);
    }
    else{
        view_picker.frame = CGRectMake(0, self.view.bounds.size.height-162, 320, 162);

    }
    [UIView commitAnimations];
}


#pragma mark - UIPickerViewDelegate / DataSource

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    

    txt_bday.enabled = TRUE;
    txt_fname.enabled = TRUE;
    txt_lname.enabled = TRUE;
    
    [scroll setContentOffset:CGPointMake(0, 0) animated:YES];
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.5];
    view_picker.frame = CGRectMake(0, self.view.bounds.size.height, 320, 162);
    [UIView commitAnimations];
    
    
    NSString *strGender = (NSString *)[ARR_GENDER objectAtIndex:row];
    lbl_gender.text = strGender;
    
    [AppSetting setGender:strGender];
    
    
    
}

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    return [ARR_GENDER count];
}

-(UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view{
    // Get the text of the row.
    NSString *rowItem = [ARR_GENDER objectAtIndex:row];
    
    UILabel *lblRow = [[UILabel alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 310, 44.0f)];
    [lblRow setTextAlignment:NSTextAlignmentCenter];
    [lblRow setTextColor: [UIColor blackColor]];
    [lblRow setText:rowItem];
    [lblRow setBackgroundColor:[UIColor clearColor]];
    [lblRow setFont:[UIFont fontWithName:ARIALFONT size:16.0]];
    
    // Return the label.
    return lblRow;
}


-(IBAction)btn_take_picture_pressed:(id)sender{
    if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
        
        // alert the user that the camera can't be accessed
        UIAlertView *noCameraAlert = [[UIAlertView alloc] initWithTitle:@"No Camera" message:@"Unable to access the camera!" delegate:nil cancelButtonTitle:@"Dismiss" otherButtonTitles:nil, nil];
        [noCameraAlert show];
        
    } else {
        picker_image = [[UIImagePickerController alloc] init];
        picker_image.delegate = self;
        picker_image.sourceType = UIImagePickerControllerSourceTypeCamera;
        picker_image.allowsEditing = YES;
        [self presentViewController:picker_image animated:YES completion:^{}];
        
    }

}
-(IBAction)btn_take_video_pressed:(id)sender{
    if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
        
        // alert the user that the camera can't be accessed
        UIAlertView *noCameraAlert = [[UIAlertView alloc] initWithTitle:@"No Camera" message:@"Unable to access the camera!" delegate:nil cancelButtonTitle:@"Dismiss" otherButtonTitles:nil, nil];
        [noCameraAlert show];
        
    } else {
        picker_image = [[UIImagePickerController alloc] init] ;
        picker_image.sourceType = UIImagePickerControllerSourceTypeCamera;
        picker_image.videoQuality = UIImagePickerControllerQualityTypeMedium;
        picker_image.mediaTypes= [NSArray arrayWithObject:@"public.movie"];
        picker_image.cameraCaptureMode = UIImagePickerControllerCameraCaptureModeVideo;
        picker_image.videoMaximumDuration = 60.0f;//no. of seconds
        picker_image.delegate = self;
        
        [self presentViewController:picker_image animated:YES completion:^{}];
        
    }
}
-(IBAction)btn_gallary_picture_pressed:(id)sender{
    picker_image = [[UIImagePickerController alloc] init];
    picker_image.delegate = self;
    picker_image.allowsEditing = YES;
    picker_image.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    picker_image.mediaTypes= [NSArray arrayWithObjects:@"public.movie",@"public.image",nil];

    [self presentViewController:picker_image animated:YES completion:^{}];

}

#pragma mark -
#pragma mark - ImagePickerControler Delegate
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    
    [self dismissViewControllerAnimated:YES completion:^{
        
        
        view_captionEpi.hidden = FALSE;
        
        btn_gallary.enabled = FALSE;
        btn_take_picture.enabled = FALSE;
        btn_take_video.enabled = FALSE;

        
        update_field = [[NSMutableDictionary alloc] init];
        

        NSString *date_time = returnCurrentDate();

        [update_field setValue:model.stationid forKey:@"stationId"];
        [update_field setValue:[AppSetting getFirstName] forKey:@"first_name"];
        [update_field setValue:[AppSetting getLarstName] forKey:@"last_name"];
        [update_field setValue:date_time forKey:@"date_time"];
        
        
        NSString *mType = [info valueForKey:UIImagePickerControllerMediaType];
        if([mType isEqualToString:@"public.movie"]){
            
            NSURL *urlvideo = [info objectForKey:@"UIImagePickerControllerMediaURL"];
            
            thumb_img = nil;
            thumb_img =  [self thumbnailImageForVideo: urlvideo atTime:1];

            NSString *send_type = @"video";
            
            [update_field setValue:send_type forKey:@"send_type"];
            
            savedVideoPath=[urlvideo path];

            AVURLAsset* incomingVideo = [[AVURLAsset alloc] initWithURL:[NSURL  fileURLWithPath:[urlvideo path]] options:nil];
            NSLog(@"orientationForTrack=%d", [self orientationForTrack: incomingVideo] );


            
        }
        else{
            UIImage *image = [(UIImage*)[info objectForKey:UIImagePickerControllerEditedImage] imageByScalingAndCroppingForSize:CGSizeMake(600, 960)];
            media_data = UIImagePNGRepresentation(image);
            
            NSString *contentId = model.photocontentid;
            NSString *send_type = @"picture";
            
            [update_field setValue:send_type forKey:@"send_type"];
            [update_field setValue:contentId forKey:@"contentId"];
            
        //    [[WebService sharedWebService] uploadMediaInvocationWithURL:strUrl dict:update_field MediaData:data delgate:self];

        }
    }];
}



- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self dismissViewControllerAnimated:YES completion:^{}];
}


-(UIImage*) thumbnailImageForVideo:(NSURL *)videoURL atTime:(NSTimeInterval)time {
    AVURLAsset *asset = [[AVURLAsset alloc] initWithURL:videoURL options:nil];
    NSParameterAssert(asset);
    AVAssetImageGenerator *assetImageGenerator = [[AVAssetImageGenerator alloc] initWithAsset:asset];
    assetImageGenerator.appliesPreferredTrackTransform = YES;
    assetImageGenerator.apertureMode = AVAssetImageGeneratorApertureModeEncodedPixels;
    
    CGImageRef thumbnailImageRef = NULL;
    CFTimeInterval thumbnailImageTime = time;
    NSError *thumbnailImageGenerationError = nil;
    thumbnailImageRef = [assetImageGenerator copyCGImageAtTime:CMTimeMake(thumbnailImageTime, 60) actualTime:NULL error:&thumbnailImageGenerationError];
    
    if (!thumbnailImageRef)
        NSLog(@"thumbnailImageGenerationError %@", thumbnailImageGenerationError);
    
    UIImage *thumbnailImage = thumbnailImageRef ? [[UIImage alloc] initWithCGImage:thumbnailImageRef] : nil;
    
    return thumbnailImage;
}

- (UIInterfaceOrientation)orientationForTrack:(AVAsset *)asset
{
    AVAssetTrack *videoTrack = [[asset tracksWithMediaType:AVMediaTypeVideo] objectAtIndex:0];
    CGSize size = [videoTrack naturalSize];
    CGAffineTransform txf = [videoTrack preferredTransform];
    
    if (size.width == txf.tx && size.height == txf.ty)
        return UIInterfaceOrientationLandscapeRight;
    else if (txf.tx == 0 && txf.ty == 0)
        return UIInterfaceOrientationLandscapeLeft;
    else if (txf.tx == 0 && txf.ty == size.width)
        return UIInterfaceOrientationPortraitUpsideDown;
    else
        return UIInterfaceOrientationPortrait;
}


-(IBAction)btn_send_media:(id)sender{
    
    view_captionEpi.hidden = TRUE;
    btn_gallary.enabled = TRUE;
    btn_take_picture.enabled = TRUE;
    btn_take_video.enabled = TRUE;
    
    [txt_caption resignFirstResponder];
    [txtView_episode resignFirstResponder];
    
    NSString *caption = txt_caption.text;
    [update_field setValue:caption forKey:@"photoCaption"];
    NSString *episodeName = txtView_episode.text;
    [update_field setValue:episodeName forKey:@"episodeName"];
    
    NSString *strUrl = model.uploadurl;
    
    if([[update_field objectForKey:@"send_type"] isEqualToString:@"video"]){
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];

        [self postViewoWithData:media_data dict:update_field];
    }
    else{
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];

        [[WebService sharedWebService] uploadMediaInvocationWithURL:strUrl dict:update_field MediaData:media_data delgate:self];
    }
    
    
}

 -(void)postViewoWithData:(NSData *)mediaData dict:(NSMutableDictionary *)dict{
     
     
     NSDate *date1=[NSDate date];
     NSDateFormatter *formatter1 = [[NSDateFormatter alloc] init];
     [formatter1 setDateFormat:@"yyyyMMddHHmmss"];
     NSString *valuestr = [formatter1 stringFromDate:date1];
     
     [formatter1 setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
     NSString *date_time = [formatter1 stringFromDate:date1];
     
     
     NSString *picname = txt_caption.text;
     NSString *moviename = txt_caption.text;
     
     NSString *picname1=[NSString stringWithFormat:@"_%@.jpg" ,valuestr];
     picname = [picname stringByAppendingString:picname1];
     
     NSString *moviename1 = [NSString stringWithFormat:@"_%@.mov" ,valuestr];
     moviename = [moviename stringByAppendingString:moviename1];
     
     
     ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:
                                    [NSURL URLWithString: model.uploadurl ] ];
     
     NSLog(@"model.uploadurl  = %@", model.uploadurl );
     
     
     [request addPostValue:model.stationid
                    forKey: @"stationId"];
     
     [request addPostValue:@"StreetTeam"          forKey: @"first_name"];
     [request addPostValue:@"iphone"              forKey: @"last_name"];
     [request addPostValue:date_time              forKey: @"date_time"];
     [request addPostValue:txt_caption.text              forKey: @"photoCaption"];
     
     if( savedVideoPath ==nil )
     {
         [request addPostValue:model.photocontentid   forKey: @"contentId"];
         [request addPostValue:@"picture"                                                                forKey: @"send_type"];
         [request setData: UIImageJPEGRepresentation(thumb_img, 0.5f)  withFileName:picname andContentType:@"image/jpeg" forKey:@"uploadFile"];
     }
     else
     {
         [request addPostValue:model.videocontentid  forKey: @"contentId"];
         [request addPostValue:model.videocontentid   forKey: @"videoProgramId"];
         [request addPostValue:txtView_episode.text              forKey: @"episodeName"];
         [request addPostValue:@"video"               forKey: @"send_type"];
         [request addData: UIImageJPEGRepresentation(thumb_img, 0.5f)  withFileName:picname andContentType:@"image/jpeg" forKey:@"uploadFile"];
         //[request addData: self.path  withFileName: moviename  andContentType:@"video/quicktime"  forKey:@"videoFileName"];
         
         [request setFile:savedVideoPath  withFileName: moviename   andContentType:@"video/quicktime" forKey:@"videoFileName"];
     }
     
     [request setShouldRedirect:YES];
    // [request setUploadProgressDelegate:progressIndicator];
     [request setDelegate:self];
     [request setDidFinishSelector:@selector(uploadRequestFinished:)];
     [request setDidFailSelector:@selector(uploadRequestFailed:)];
     
     // [request setShouldAttemptPersistentConnection:NO];
     [request setTimeOutSeconds:60]; 
     [request startAsynchronous];
}

- (void)uploadRequestFinished:(ASIHTTPRequest *)request{
    NSString *responseString = [request responseString];
    NSLog(@"upload response%@", responseString);
    txt_caption.text = @"";
    txtView_episode.text = @"";
    
    [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    
    alert = [[UIAlertView alloc]initWithTitle:@"" message:@"Upload success!" delegate:self cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
    [alert show];
    
}

- (void)uploadRequestFailed:(ASIHTTPRequest *)request{
    
    [MBProgressHUD hideAllHUDsForView:self.view animated:YES];

    
    NSLog(@" Error -   file upload failed: \"%@\"",[[request error] localizedDescription]);
    [Utils showAlertMessage:@"" Message:@"Upload failed!"];
   // [self cancel];
}

- (void)cancel
{
    [self.navigationController popToRootViewControllerAnimated:YES];
}




#pragma mark - UPload media Delegate
-(void)upLoadMediaInvocationDidFinish:(UpLoadMediaInvocation *)invocation withResults:(NSString *)result withError:(NSError *)error{
    
    [MBProgressHUD hideAllHUDsForView:self.view animated:YES];

    
    NSLog(@"upload = %@",result);
    
    NSArray * arr = [result componentsSeparatedByString:@":"];
    
    if([[arr objectAtIndex:0] isEqualToString:@"Success"]){
        txt_caption.text = @"";
        txtView_episode.text = @"";
        
        alert = [[UIAlertView alloc]initWithTitle:@"" message:@"Picture sent." delegate:self cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
        [alert show];
        
        
        
    }
    else{

        [Utils showAlertMessage:@"" Message:@"Picture not sent."];
    }
    
}

#pragma mark - AlertView Delegate

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if(alertView == alert){
        
        if(buttonIndex == 0){
            [self cancel];
        }
    }
}

#pragma mark - TextView Delegate
- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text {
    NSRange resultRange = [text rangeOfCharacterFromSet:[NSCharacterSet newlineCharacterSet] options:NSBackwardsSearch];
    if ([text length] == 1 && resultRange.location != NSNotFound) {
        [textView resignFirstResponder];
        return NO;
    }
    
    return YES;
}



-(void)addKeyboardControls
{
    // Initialize the keyboard controls
    self.keyboardControls = [[BSKeyboardControls alloc] init];
    
    // Set the delegate of the keyboard controls
    self.keyboardControls.delegate = self;
    
    // Add all text fields you want to be able to skip between to the keyboard controls
    // The order of thise text fields are important. The order is used when pressing "Previous" or "Next"
    
    
    self.keyboardControls.textFields = [NSArray arrayWithObjects:txt_fname,
                                        txt_lname,
                                        txt_bday,
                                        nil];
    
    
    // Set the style of the bar. Default is UIBarStyleBlackTranslucent.
    if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0"))
    {
        self.keyboardControls.barStyle = UIBarStyleDefault;
    }
    else
    {
        self.keyboardControls.barStyle = UIBarStyleBlackTranslucent;
    }
    // Set the tint color of the "Previous" and "Next" button. Default is black.
    self.keyboardControls.previousNextTintColor = [UIColor blackColor];
    
    // Set the tint color of the done button. Default is a color which looks a lot like the original blue color for a "Done" butotn
    self.keyboardControls.doneTintColor = [UIColor colorWithRed:34.0/255.0 green:164.0/255.0 blue:255.0/255.0 alpha:1.0];
    
    // Set title for the "Previous" button. Default is "Previous".
    self.keyboardControls.previousTitle = @"Previous";
    
    // Set title for the "Next button". Default is "Next".
    self.keyboardControls.nextTitle = @"Next";
    
    // Add the keyboard control as accessory view for all of the text fields
    // Also set the delegate of all the text fields to self
    for (id textField in self.keyboardControls.textFields)
    {
        if ([textField isKindOfClass:[UITextField class]])
        {
            ((UITextField *) textField).inputAccessoryView = self.keyboardControls;
            ((UITextField *) textField).delegate = self;
        }
    }
}

-(void)scrollViewToCenterOfScreen:(UIView *)theView
{
    CGFloat viewCenterY = theView.center.y;
    CGRect applicationFrame = [[UIScreen mainScreen] applicationFrame];
    
    float height_factor = IS_IPHONE_5?150:200;

    CGFloat availableHeight = applicationFrame.size.height - height_factor; // Remove area covered by keyboard 200
    
    CGFloat y = viewCenterY - availableHeight / 2.0;
    if (y < 0) {
        y = 0;
    }

    [scroll setContentOffset:CGPointMake(0, y) animated:YES];
}

#pragma mark- BSControlKeyDelegate

- (void)keyboardControlsDonePressed:(BSKeyboardControls *)controls
{
    [controls.activeTextField resignFirstResponder];
    
    [scroll setContentOffset:CGPointMake(0, 0) animated:YES];
    
}


- (void)keyboardControlsPreviousNextPressed:(BSKeyboardControls *)controls withDirection:(KeyboardControlsDirection)direction andActiveTextField:(id)textField
{
    [textField becomeFirstResponder];
    [self scrollViewToCenterOfScreen:textField];
}


-(void)resignKeyboard
{
    [txt_fname resignFirstResponder];
    [txt_lname resignFirstResponder];
    [txt_bday resignFirstResponder];
}


- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    
    if ([self.keyboardControls.textFields containsObject:textField])
        self.keyboardControls.activeTextField = textField;
    
    [self scrollViewToCenterOfScreen:textField];
    return YES;
}

#pragma mark -
#pragma mark - TextField Delegate
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
        return YES;
    
}-(void)textFieldDidBeginEditing:(UITextField *)textField{
    
}

-(void)textFieldDidEndEditing:(UITextField *)textField{

    NSCharacterSet *set = [NSCharacterSet whitespaceCharacterSet];

    if(textField == txt_fname){
        if( [[txt_fname.text stringByTrimmingCharactersInSet: set] length] == 0){
            txt_fname.text = @"";
        }
        else{
            [AppSetting setFirstName:txt_fname.text];
        }
    }
    if(textField == txt_lname){
        if( [[txt_lname.text stringByTrimmingCharactersInSet: set] length] == 0){
            txt_lname.text = @"";
        }
        else{
            [AppSetting setLastName:txt_lname.text];
        }
    }
    else if(txt_bday == textField){
        
        NSString *strVal = [txt_bday.text stringByTrimmingCharactersInSet: set];
        
        if([strVal intValue] < 13){
            txt_bday.text = @"";
            [AppSetting setBdayYear:@""];

            UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"" message:@"You must be at least 13 years old." delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles: nil];
            [alert show];
            
        }
        else{
            [AppSetting setBdayYear:strVal];
        }
    }
       
}




-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    
    
    
    [textField resignFirstResponder];
    [self keyboardControlsDonePressed:self.keyboardControls];
    
    
    return TRUE;
}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
