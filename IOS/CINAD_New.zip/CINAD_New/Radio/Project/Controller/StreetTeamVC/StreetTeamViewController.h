//
//  StreetTeamViewController.h
//  Radio
//
//  Created by Om Prakash on 18/08/14.
//  Copyright (c) 2014 Octal Info Solution. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseUrlModel.h"
#import "BSKeyboardControls.h"
#import "WebService.h"
#import <MediaPlayer/MediaPlayer.h>



@interface StreetTeamViewController : UIViewController<UIImagePickerControllerDelegate,UINavigationControllerDelegate,UITextFieldDelegate,UIPickerViewDataSource,UIPickerViewDelegate,UITextViewDelegate,BSKeyboardControlsDelegate,UIAlertViewDelegate>{
    BaseUrlModel *model;
    
    IBOutlet UIImageView *bg_imgView;
    
    IBOutlet UIButton *btn_take_picture;
    IBOutlet UIButton *btn_take_video;
    IBOutlet UIButton *btn_gallary;

    UIImagePickerController* picker_image;
    IBOutlet UIImageView *take_img;
    
    IBOutlet UIView *view_appSetting;
    IBOutlet UIScrollView *scroll;
    
    IBOutlet UITextField *txt_fname,*txt_lname,*txt_bday;
    
    IBOutlet UILabel *lbl_gender;
    
    
    IBOutlet UIView *view_picker;
    IBOutlet UIPickerView *picker_gender;
    
    IBOutlet UIButton *btn_agree;
    
    IBOutlet UITextView *txtView_episode;
    IBOutlet UITextField *txt_caption;
    IBOutlet UIView *view_captionEpi;
    
    NSMutableDictionary *update_field ;
    NSData *media_data;
    
    IBOutlet UIView *view_term;
    
    NSMutableData *response;
    
    UIImage *thumb_img;
    NSString *savedVideoPath;
    
    UIAlertView *alert;
    
    
}
@property(nonatomic, retain)BSKeyboardControls *keyboardControls;

-(IBAction)btn_form_submit:(id)sender;
-(IBAction)btn_agre_pressed:(id)sender;
-(IBAction)btn_take_picture_pressed:(id)sender;
-(IBAction)btn_take_video_pressed:(id)sender;
-(IBAction)btn_gallary_picture_pressed:(id)sender;
-(IBAction)btn_send_media:(id)sender;

-(IBAction)btn_gender_pressed:(id)sender;

-(IBAction)showTermView:(id)sender;
-(IBAction)closeTermView:(id)sender;

@end
