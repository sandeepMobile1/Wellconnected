//
//  FacebookViewController.h
//  Radio
//
//  Created by Om Prakash on 18/08/14.
//  Copyright (c) 2014 Octal Info Solution. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseUrlModel.h"


@interface FacebookViewController : UIViewController<UIWebViewDelegate>{
    IBOutlet UIWebView *facebook_web;
    BaseUrlModel *model;

}

@end
