//
//  TwitterViewController.h
//  Radio
//
//  Created by Om Prakash on 18/08/14.
//  Copyright (c) 2014 Octal Info Solution. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseUrlModel.h"

@interface TwitterViewController : UIViewController<UIWebViewDelegate>{
    IBOutlet UIWebView *twitter_web;
    BaseUrlModel *model;

}


@end
