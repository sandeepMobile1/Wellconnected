//
//  RadioViewController.m
//  Radio
//
//  Created by Om Prakash on 18/08/14.
//  Copyright (c) 2014 Octal Info Solution. All rights reserved.
//

#import "RadioViewController.h"
#import "MediaPlayer/MPVolumeView.h"
#import "TBXML.h"
#import "BannerGroupIDs.h"
#import "BaseUrlModel.h"


@interface RadioViewController (Private)<BannerGroupInvocationDelegate>

@end

@implementation RadioViewController
@synthesize arrBannerIDs;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    btnPlay.hidden = FALSE;
    btnPause.hidden = TRUE;
    
    self.arrBannerIDs = [[NSMutableArray alloc]init];
    
    
    if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0")){
        
        if(IS_IPHONE_5){
            
        }
        else{
            headerImageView.frame = CGRectMake(0, 20, headerImageView.frame.size.width, headerImageView.frame.size.height);
            view_tool.frame = CGRectMake(0, headerImageView.frame.size.height+20, view_tool.frame.size.width, view_tool.frame.size.height-88);
            scroll.frame = CGRectMake(0, scroll.frame.origin.y, scroll.frame.size.width, 262-40);
        }
        
    }
    else{
        if(IS_IPHONE_5){
            headerImageView.frame = CGRectMake(0, 0, headerImageView.frame.size.width, headerImageView.frame.size.height);
            view_tool.frame = CGRectMake(0, headerImageView.frame.size.height, view_tool.frame.size.width, view_tool.frame.size.height);
            scroll.frame = CGRectMake(0, scroll.frame.origin.y, scroll.frame.size.width, 350-40);

        }
        else{
            headerImageView.frame = CGRectMake(0, 0, headerImageView.frame.size.width, headerImageView.frame.size.height);
            view_tool.frame = CGRectMake(0, headerImageView.frame.size.height, view_tool.frame.size.width, 310);
            scroll.frame = CGRectMake(0, scroll.frame.origin.y, scroll.frame.size.width, 262-40);

        }
    }
    
    arryAdImage = [[NSMutableArray alloc]init];
    arryAdUrl  = [[NSMutableArray alloc]init];

    
    [self performSelector:@selector(getAppInfo) withObject:nil afterDelay:0.1];

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(playButtonPressed:) name:@"play_fm" object:nil];

}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:YES];
    [self.navigationController setNavigationBarHidden:YES animated:YES];
    
    [AppDelegate sharedAppDelegate].tabBarController.selectedIndex = 0;
    

    
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:YES];

}

#pragma mark - BaseURL Method and Delegate

-(void)getAppInfo{
    if (isInternetAvailable())
    {
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        [[WebService sharedWebService] baseUrlRequest:self];
    }
    else
    {
        showInternetAlertMessage();
    }
    
}

#pragma mark - BaesUrl Invocation Delegate

-(void)baseUrlInvocationDidFinish:(BaseUrlInvocation *)invocation withResults:(NSString *)result withError:(NSError *)error{
    NSLog(@"result = %@",result);
    
    CFRunLoopStop(CFRunLoopGetCurrent());
	theXML = result;
    
    [self parseXML];
    
}

-(void)parseXML{
    
    TBXML *xmlTB=[[TBXML alloc] initWithXMLString:theXML];
	TBXMLElement *rootElement=xmlTB.rootXMLElement;
	
	if (rootElement) {
        
        BaseUrlModel *base_url = [[BaseUrlModel alloc] init];
        
        TBXMLElement *titleElement = [TBXML childElementNamed:@"title" parentElement:rootElement];
        base_url.title=[TBXML textForElement:titleElement];
        
        TBXMLElement *vortalCallLettersElement = [TBXML childElementNamed:@"vortalCallLetters" parentElement:rootElement];
        base_url.vortalCallLetters=[TBXML textForElement:vortalCallLettersElement];
        
        TBXMLElement *vortatStationIdElement = [TBXML childElementNamed:@"vortatStationId" parentElement:rootElement];
        base_url.vortatStationId=[TBXML textForElement:vortatStationIdElement];
        
        TBXMLElement *websiteUrlElement = [TBXML childElementNamed:@"websiteUrl" parentElement:rootElement];
        base_url.websiteUrl=[TBXML textForElement:websiteUrlElement];
        
        TBXMLElement *facebookElement = [TBXML childElementNamed:@"facebook" parentElement:rootElement];
        base_url.facebook=[TBXML textForElement:facebookElement];
        
        TBXMLElement *twitterElement = [TBXML childElementNamed:@"twitter" parentElement:rootElement];
        base_url.twitter=[TBXML textForElement:twitterElement];
        
        TBXMLElement *uploadurlElement = [TBXML childElementNamed:@"uploadurl" parentElement:rootElement];
        base_url.uploadurl=[TBXML textForElement:uploadurlElement];
        
        TBXMLElement *fgUrlElement = [TBXML childElementNamed:@"fgUrl" parentElement:rootElement];
        base_url.fgUrl=[TBXML textForElement:fgUrlElement];
        
        TBXMLElement *iosStreamUrlElement = [TBXML childElementNamed:@"iosStreamUrl" parentElement:rootElement];
        base_url.iosStreamUrl=[TBXML textForElement:iosStreamUrlElement];
        
        TBXMLElement *bannerGroupIdElement = [TBXML childElementNamed:@"bannerGroupId" parentElement:rootElement];
        base_url.bannerGroupId=[TBXML textForElement:bannerGroupIdElement];
        
        TBXMLElement *headerImageElement = [TBXML childElementNamed:@"headerImage" parentElement:rootElement];
        base_url.headerImage=[TBXML textForElement:headerImageElement];
        
        TBXMLElement *signupUrlElement = [TBXML childElementNamed:@"signupUrl" parentElement:rootElement];
        base_url.signupUrl=[TBXML textForElement:signupUrlElement];
        
        TBXMLElement *infoUrlElement = [TBXML childElementNamed:@"infoUrl" parentElement:rootElement];
        base_url.infoUrl=[TBXML textForElement:infoUrlElement];
        
        TBXMLElement *stationidElement = [TBXML childElementNamed:@"stationid" parentElement:rootElement];
        base_url.stationid=[TBXML textForElement:stationidElement];
        
        TBXMLElement *photocontentidElement = [TBXML childElementNamed:@"photocontentid" parentElement:rootElement];
        base_url.photocontentid=[TBXML textForElement:photocontentidElement];
        
        TBXMLElement *videocontentidElement = [TBXML childElementNamed:@"videocontentid" parentElement:rootElement];
        base_url.videocontentid=[TBXML textForElement:videocontentidElement];
        
        TBXMLElement *termsofuseElement = [TBXML childElementNamed:@"termsofuse" parentElement:rootElement];
        base_url.termsofuse=[TBXML textForElement:termsofuseElement];
        
        BOOL state = [AppSetting saveBaseUrlSetting:base_url];
        
        if(state){
            NSLog(@"successfully save");
            
            model = (BaseUrlModel *)[AppSetting getBaseUrlSetting];
            
            NSString *img = model.headerImage;
            
            [headerImageView setImageWithURL:[NSURL URLWithString:!([img isEqual:(NSString*)[NSNull null]])? img:@""] placeholderImage:[UIImage imageNamed:@"thumnail_img_hover.png"]];
            
            [self playselectedsong];
            
            [[WebService sharedWebService] BannerGroupUrlRequest:self];
            
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                // No explicit autorelease pool needed here.
                // The code runs in background, not strangling
                // the main run loop.
                
                dispatch_sync(dispatch_get_main_queue(), ^{
                    // This will be called on the main thread, so that
                    // you can update the UI, for example.
                    
                    
                    model = (BaseUrlModel *)[AppSetting getBaseUrlSetting];
                    
                    NSURL *url = [NSURL URLWithString:model.fgUrl];
                    parser = [[NSXMLParser alloc] initWithContentsOfURL:url];
                    [parser setDelegate:self];
                    [parser setShouldResolveExternalEntities:NO];
                    [parser parse];
                    
                    
                });
                
            });
            
            
        }
        else{
            NSLog(@"not save");
        }
        
    }
    else{
        NSLog(@"Root element not found");
        
    }
    
    [MBProgressHUD hideAllHUDsForView:self.view animated:YES];

}

-(void)bannerGroupInvocationDidFinish:(BannerGroupInvocation *)invocation withResults:(NSString *)result withError:(NSError *)error{
    NSLog(@"Banner Result = %@",result);
    
    
    NSLog(@"Banner Result = %@",result);
    
    NSString *theXMLData = [NSString stringWithFormat:@"%@",result];
    
    TBXML *xmlTB=[[TBXML alloc] initWithXMLString:theXMLData];
	TBXMLElement *rootElement=xmlTB.rootXMLElement;
    
    [self.arrBannerIDs removeAllObjects];
	
	if (rootElement) {
        
        TBXMLElement *image = [TBXML childElementNamed:@"image" parentElement:rootElement];
        NSString *str_image=[TBXML textForElement:image];
        
        
        TBXMLElement *url = [TBXML childElementNamed:@"url" parentElement:rootElement];
        NSString *str_url=[TBXML textForElement:url];
        
        str_url = decodeFromPercentEscapeString(str_url);
        str_image = decodeFromPercentEscapeString(str_image);
        
        NSLog(@"banner Image = %@",str_image);
        
        BannerGroupIDs *bannerIDs = [[BannerGroupIDs alloc]init];
        bannerIDs.image = str_image;
        bannerIDs.url = str_url;
        
        [img_banner setImageWithURL:[NSURL URLWithString:!([str_image isEqual:(NSString*)[NSNull null]])? str_image:@""] placeholderImage:[UIImage imageNamed:@"thumnail_img_hover.png"]];
        [self.arrBannerIDs addObject:bannerIDs];
    }
    else{
        NSLog(@"Root element not found");
        [[WebService sharedWebService] BannerGroupUrlRequest:self];
    }
}

-(IBAction)btn_banner_pressed:(id)sender{
    BannerGroupIDs *banner = (BannerGroupIDs *)[self.arrBannerIDs objectAtIndex:0];
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:banner.url]];
}


#pragma mark - NsXMLParser Delegates

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict {
    
    element = elementName;
    
   /// NSLog(@"elementName =%@",elementName);
    if ([element isEqualToString:@"media:thumbnail"]) {
        
        NSLog(@"thumb url%@", [attributeDict valueForKey:@"url"]);
        
        [arryAdImage addObject:[attributeDict valueForKey:@"url"]];
        
      //  NSLog(@"arryAdImage = %@",arryAdImage);
        
    }
}


- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName {
    
    
}

- (void)parser:(NSXMLParser *)parser foundCharacters:(NSString *)string {
 
}


-(void)parser:(NSXMLParser *)parser foundCDATA:(NSData *)CDATABlock{
    
    if([element isEqualToString:@"link"]){
        NSString *someString = [[NSString alloc] initWithData:CDATABlock encoding:NSUTF8StringEncoding];

      //  NSLog(@"someString = %@",someString);
        
        [arryAdUrl addObject:someString];
      //  NSLog(@"arryAdUrl = %@",arryAdUrl);
    }
    
   
}


- (void)parserDidEndDocument:(NSXMLParser *)parser {
    
    
    
    NSLog(@"array Image = %@",arryAdImage);
    NSLog(@"arry Ling url= %@",arryAdUrl);
    
    [arryAdUrl removeObjectAtIndex:0];
    
    NSLog(@"arry Ling url= %@",arryAdUrl);
    
    
    
    
    Page_no=[arryAdImage count];
    
    scroll.contentSize = CGSizeMake(scroll.frame.size.width * Page_no, 0);
    scroll.scrollsToTop = NO;
    scroll.delegate = self;
    [scroll setCanCancelContentTouches:NO];
	scroll.indicatorStyle = UIScrollViewIndicatorStyleWhite;
	scroll.clipsToBounds = YES;
	scroll.scrollEnabled = YES;
	scroll.pagingEnabled = YES;
    scroll.showsHorizontalScrollIndicator = NO;
    scroll.showsVerticalScrollIndicator = NO;
    [scroll setBackgroundColor:[UIColor whiteColor]];
    
    
    
    pageControl.numberOfPages = Page_no;
    pageControl.currentPage = 0;
    
    if(DEVICE_OS_VERSION >=6.0)
    {
        pageControl.pageIndicatorTintColor = [UIColor grayColor];
        pageControl.currentPageIndicatorTintColor = [UIColor blackColor];
        
    }
    [self loadScrollViewWithPage:0 ];
}




#pragma mark - AVPlayer Delegates and Functions

-(void)playselectedsong{
    
    
    NSString *str_url = model.iosStreamUrl;
    
    NSLog(@"str_url = %@",str_url);

    AVPlayer *player = [[AVPlayer alloc]initWithURL:[NSURL URLWithString:str_url]];
    fmPlayer = player;
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(playerItemDidReachEnd:)
                                                 name:AVPlayerItemDidPlayToEndTimeNotification
                                               object:[fmPlayer currentItem]];
    [fmPlayer addObserver:self forKeyPath:@"status" options:0 context:nil];
    
    
    
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
    
    if (object == fmPlayer && [keyPath isEqualToString:@"status"]) {
        if (fmPlayer.status == AVPlayerStatusFailed) {
            NSLog(@"AVPlayer Failed");
        } else if (fmPlayer.status == AVPlayerStatusReadyToPlay) {
            NSLog(@"AVPlayerStatusReadyToPlay");
        //    [fmPlayer play];
        } else if (fmPlayer == AVPlayerItemStatusUnknown) {
            NSLog(@"AVPlayer Unknown");
        }
    }
}

- (void)playerItemDidReachEnd:(NSNotification *)notification {
    
    //  code here to play next sound file
}
-(void)showPlayBtn{
    btnPlay.hidden = FALSE;
    btnPause.hidden = TRUE;
}
-(void)showPauseBtn{
    btnPlay.hidden = TRUE;
    btnPause.hidden = FALSE;
}

-(IBAction)playButtonPressed:(id)sender{
    [self showPauseBtn];
    [fmPlayer play];
}

-(IBAction)pauseButtonPressed:(id)sender{
    [self showPlayBtn];
    [fmPlayer pause];
}

-(IBAction)sliderVolumeChange:(id)sender{
    
    float volume = (float)sliderVolume.value;
    
    NSLog(@"volume = %f",volume);
    
    if(SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"7.0")){
        fmPlayer.volume=volume;
    }
    else{
 /*       NSLog(@"slider :%f ", sliderVolume.value);
        
        long seconds = CMTimeGetSeconds(fmPlayer.currentTime);
        
        NSArray *audioTracks = [[playerItem asset] tracks];
        
        AVMutableAudioMixInputParameters *audioInputParams = [AVMutableAudioMixInputParameters audioMixInputParametersWithTrack:audioTracks[0]];
        [audioInputParams setVolumeRampFromStartVolume:volume toEndVolume:0.0 timeRange:CMTimeRangeMake(CMTimeMakeWithSeconds(seconds, 1.0), CMTimeMakeWithSeconds(3.0, 1.0))];
        
        AVMutableAudioMix *audioMix = [AVMutableAudioMix audioMix];
        [audioMix setInputParameters:@[audioInputParams]];
        
        [playerItem setAudioMix:audioMix]; */
    }
    
}

#pragma mark - ScrollView
#pragma mark - PageControll With UiScrollView

- (void)loadScrollViewWithPage:(int)page
{
    
    if (page > [arryAdImage count]-1 || page < 0 )
    {
        return;
    }
    self.view.backgroundColor = [UIColor whiteColor];
    pageControl.hidden=NO;
    viewSlideBase = [[UIView alloc]init];
    viewSlideBase.frame = CGRectMake(320*page, 0, 320,scroll.frame.size.height );
    [viewSlideBase setBackgroundColor:[UIColor whiteColor]];
    [scroll addSubview:viewSlideBase];
    
     imgView = [[UIImageView alloc]init];
    [viewSlideBase addSubview:imgView];
    
    
    
    buttonLink = [UIButton buttonWithType:UIButtonTypeCustom];

    [buttonLink addTarget:self
                action:@selector(goToWebLink:)
      forControlEvents:(UIControlEvents)UIControlEventTouchDown];
    buttonLink.tag = page;
    [viewSlideBase addSubview:buttonLink];
    [viewSlideBase bringSubviewToFront:buttonLink];
    
    
    
    if(IS_IPHONE_5){
        
        imgView.frame = CGRectMake(0, 0, 320, scroll.frame.size.height);
        buttonLink.frame = CGRectMake(0, 0, 320, scroll.frame.size.height);

        NSString *img = [arryAdImage objectAtIndex:page];
        
        [imgView setImageWithURL:[NSURL URLWithString:!([img isEqual:(NSString*)[NSNull null]])? img:@""] placeholderImage:[UIImage imageNamed:@"thumnail_img_hover.png"]];
    }
    else{
        
        imgView.frame = CGRectMake(0, 0, 320, scroll.frame.size.height);
        buttonLink.frame = CGRectMake(0, 0, 320, scroll.frame.size.height);

        NSString *img = [arryAdImage objectAtIndex:page];
        
        [imgView setImageWithURL:[NSURL URLWithString:!([img isEqual:(NSString*)[NSNull null]])? img:@""] placeholderImage:[UIImage imageNamed:@"thumnail_img_hover.png"]];
        
    }
    
    
    
    
    
    
    imgView = nil;
}

- (void)scrollViewDidScroll:(UIScrollView *)sender {
   	
    CGFloat pageWidth = scroll.frame.size.width;
    int page = floor((scroll.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
    pageControl.currentPage=page;
    
    if (currentPageNumber!=page)
    {
        currentPageNumber=page;
        if (page > [arryAdImage count] || page < 0)
        {
            return;
        }
        else
        {
            [self loadScrollViewWithPage:page];
        }
    }
}

-(void)goToWebLink:(id)sender{
    
    UIButton *btn = (UIButton *)sender;
    
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[arryAdUrl objectAtIndex:btn.tag]]];

    
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
