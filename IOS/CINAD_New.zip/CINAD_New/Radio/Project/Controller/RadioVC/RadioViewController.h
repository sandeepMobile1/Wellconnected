//
//  RadioViewController.h
//  Radio
//
//  Created by Om Prakash on 18/08/14.
//  Copyright (c) 2014 Octal Info Solution. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
#import "BaseUrlModel.h"
#import "WebService.h"


@interface RadioViewController : UIViewController<AVAudioPlayerDelegate,BaseUrlInvocationDelegate,UIScrollViewDelegate,NSXMLParserDelegate>{

    NSString *theXML;

    
    NSURL* fmURL;
    
	AVPlayer* fmPlayer;
    AVPlayerItem * fmPlayerItem;
    
    BOOL seekToZeroBeforePlay;

    
    ////
    
    IBOutlet UIButton *btnPlay,*btnPause;
    IBOutlet UISlider *sliderVolume;
    
    AVURLAsset *assetUrl;
    
    AVPlayerItem *playerItem;
    
    IBOutlet UIImageView *headerImageView;
    
    BaseUrlModel *model;
    IBOutlet UIScrollView *scroll;
    IBOutlet UIPageControl *pageControl;
    NSUInteger Page_no;
    UIView *viewSlideBase;
    UIImageView *imgView;
    int lastPageNumber,currentPageNumber;
    
    UIButton *buttonLink;


    
    IBOutlet UIView *view_tool;
    
    NSMutableArray *arryAdImage;
    NSMutableArray *arryAdUrl;
    
    
    NSXMLParser *parser;
    NSString *element;
    
    IBOutlet UIButton *btn_banner;
    IBOutlet UIImageView *img_banner;
    
    
    

}

@property(nonatomic, strong)NSMutableArray *arrBannerIDs;


-(IBAction)btn_banner_pressed:(id)sender;
-(IBAction)playButtonPressed:(id)sender;
-(IBAction)pauseButtonPressed:(id)sender;
-(IBAction)sliderVolumeChange:(id)sender;

-(void)showPlayBtn;
-(void)showPauseBtn;

@end
