//
//  AppSetting.h
//  RoboFoto
//
//  Created by Om Prakash on 1/15/14.
//  Copyright (c) 2014 Vijay Kumar. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BaseUrlModel.h"

@interface AppSetting : NSObject

/// User Id
+(void)setUserId:(NSString *)uesr_Id;
+(NSString *)getUserId;

//// First Name
+(void)setFirstName:(NSString *)userName;
+(NSString *)getFirstName;

//// Last Name
+(void)setLastName:(NSString *)userName;
+(NSString *)getLarstName;

//// BDay Year
+(void)setBdayYear:(NSString *)strBday;
+(NSString *)getBdayYear;

//// Gender
+(void)setGender:(NSString *)gender;
+(NSString *)getGender;

//// I Agree
+(void)setIsAgree:(BOOL)status;
+(BOOL)getIsAgree;



+(BOOL)saveBaseUrlSetting:(BaseUrlModel *)baesUrlInfo;
+(BaseUrlModel *)getBaseUrlSetting;
+(NSString *)getPlistPath;


+(void)setAlarm:(BOOL )status;
+(BOOL)isAlarm;


@end
