//
//  AppSetting.m
//  RoboFoto
//
//  Created by Om Prakash on 1/15/14.
//  Copyright (c) 2014 Vijay Kumar. All rights reserved.
//

#import "AppSetting.h"

@implementation AppSetting


+(NSString *)plist_dict{
    
    NSString *rootPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSString *plistPath = [rootPath stringByAppendingPathComponent:@"appSetting.plist"];
    return  plistPath;
}

+(NSString *)getPlistPath{
    
    NSError *error;
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES); //1 Create a list of paths.
    NSString *documentsDirectory = [paths objectAtIndex:0]; //2 Get a path to your documents directory from the list.
    NSString *plistPath = [documentsDirectory stringByAppendingPathComponent:@"DataBaseUrl.plist"]; //3 Create a full file path.
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    if (![fileManager fileExistsAtPath: plistPath]) //4 Check if file exists.
    {
        NSString *bundle = [[NSBundle mainBundle] pathForResource:@"DataBaseUrl" ofType:@"plist"]; //5 Get a path to your plist created before in bundle directory (by Xcode).
        [fileManager copyItemAtPath:bundle toPath: plistPath error:&error]; //6 Copy this plist to your documents directory.
    }
    return  plistPath;
}


+(void)setUserId:(NSString *)uesr_Id{
    // userId
    NSString *path = [AppSetting plist_dict];
    NSMutableDictionary *plist_dict=[[NSMutableDictionary alloc]initWithContentsOfFile:path];
    
    if(plist_dict == nil)
    {
        plist_dict = [[NSMutableDictionary alloc] init];
    }
    [plist_dict setObject:uesr_Id forKey:@"userId"];
    [plist_dict writeToFile:path atomically:YES];

}
+(NSString *)getUserId{
    NSString *path = [AppSetting plist_dict];
    NSMutableDictionary *plist_dict=[[NSMutableDictionary alloc]initWithContentsOfFile:path];
    
    NSString *uesrId = [plist_dict objectForKey:@"userId"];
    return uesrId;
    
}



//// First Name
+(void)setFirstName:(NSString *)userName{
    NSString *path = [AppSetting plist_dict];
    NSMutableDictionary *plist_dict=[[NSMutableDictionary alloc]initWithContentsOfFile:path];
    
    if(plist_dict == nil)
    {
        plist_dict = [[NSMutableDictionary alloc] init];
    }
    [plist_dict setObject:userName forKey:@"street_fname"];
    [plist_dict writeToFile:path atomically:YES];
}
+(NSString *)getFirstName{
    NSString *path = [AppSetting plist_dict];
    NSMutableDictionary *plist_dict=[[NSMutableDictionary alloc]initWithContentsOfFile:path];
    
    NSString *name = [plist_dict objectForKey:@"street_fname"];
    return name;
}

//// Last Name
+(void)setLastName:(NSString *)userName{
    NSString *path = [AppSetting plist_dict];
    NSMutableDictionary *plist_dict=[[NSMutableDictionary alloc]initWithContentsOfFile:path];
    
    if(plist_dict == nil)
    {
        plist_dict = [[NSMutableDictionary alloc] init];
    }
    [plist_dict setObject:userName forKey:@"street_lname"];
    [plist_dict writeToFile:path atomically:YES];
}
+(NSString *)getLarstName{
    NSString *path = [AppSetting plist_dict];
    NSMutableDictionary *plist_dict=[[NSMutableDictionary alloc]initWithContentsOfFile:path];
    
    NSString *name = [plist_dict objectForKey:@"street_lname"];
    return name;
}

//// BDay Year
+(void)setBdayYear:(NSString *)strBday{
    NSString *path = [AppSetting plist_dict];
    NSMutableDictionary *plist_dict=[[NSMutableDictionary alloc]initWithContentsOfFile:path];
    
    if(plist_dict == nil)
    {
        plist_dict = [[NSMutableDictionary alloc] init];
    }
    [plist_dict setObject:strBday forKey:@"street_bday"];
    [plist_dict writeToFile:path atomically:YES];
}
+(NSString *)getBdayYear{
    NSString *path = [AppSetting plist_dict];
    NSMutableDictionary *plist_dict=[[NSMutableDictionary alloc]initWithContentsOfFile:path];
    
    NSString *strBday = [plist_dict objectForKey:@"street_bday"];
    return strBday;
}

//// Gender
+(void)setGender:(NSString *)gender{
    NSString *path = [AppSetting plist_dict];
    NSMutableDictionary *plist_dict=[[NSMutableDictionary alloc]initWithContentsOfFile:path];
    
    if(plist_dict == nil)
    {
        plist_dict = [[NSMutableDictionary alloc] init];
    }
    [plist_dict setObject:gender forKey:@"street_gender"];
    [plist_dict writeToFile:path atomically:YES];

}
+(NSString *)getGender{
    NSString *path = [AppSetting plist_dict];
    NSMutableDictionary *plist_dict=[[NSMutableDictionary alloc]initWithContentsOfFile:path];
    
    NSString *gender = [plist_dict objectForKey:@"street_gender"];
    return gender;
}

//// I Agree
+(void)setIsAgree:(BOOL)status{
    NSString *path = [AppSetting plist_dict];
    NSMutableDictionary *plist_dict=[[NSMutableDictionary alloc]initWithContentsOfFile:path];
    
    if(plist_dict == nil)
    {
        plist_dict = [[NSMutableDictionary alloc] init];
    }
    
    [plist_dict setObject:[NSNumber numberWithBool:status] forKey:@"street_isAgree"];
    [plist_dict writeToFile:path atomically:YES];
}
+(BOOL)getIsAgree{
    NSString *path = [AppSetting plist_dict];
    NSMutableDictionary *plist_dict=[[NSMutableDictionary alloc]initWithContentsOfFile:path];
    
    BOOL myBool = [[plist_dict objectForKey:@"street_isAgree"] boolValue];
    
    return myBool;
}

+(BOOL)saveBaseUrlSetting:(BaseUrlModel *)baesUrlInfo{
    @try
    {
        NSString *path = [AppSetting getPlistPath];
        NSMutableDictionary *dict=[[NSMutableDictionary alloc]initWithContentsOfFile:path];
        if(dict == nil)
            dict=[[NSMutableDictionary alloc] init];
        
        [dict setValue:baesUrlInfo.title forKey:@"title"];
        [dict setValue:baesUrlInfo.vortalCallLetters forKey:@"vortalCallLetters"];
        [dict setValue:baesUrlInfo.vortatStationId forKey:@"vortatStationId"];
        [dict setValue:baesUrlInfo.websiteUrl forKey:@"websiteUrl"];
        [dict setValue:baesUrlInfo.facebook forKey:@"facebook"];
        [dict setValue:baesUrlInfo.twitter forKey:@"twitter"];
        [dict setValue:baesUrlInfo.uploadurl forKey:@"uploadurl"];
        [dict setValue:baesUrlInfo.fgUrl forKey:@"fgUrl"];
        [dict setValue:baesUrlInfo.iosStreamUrl forKey:@"iosStreamUrl"];
        [dict setValue:baesUrlInfo.bannerGroupId forKey:@"bannerGroupId"];
        [dict setValue:baesUrlInfo.headerImage forKey:@"headerImage"];
        [dict setValue:baesUrlInfo.signupUrl forKey:@"signupUrl"];
        [dict setValue:baesUrlInfo.infoUrl forKey:@"infoUrl"];
        [dict setValue:baesUrlInfo.stationid forKey:@"stationid"];
        [dict setValue:baesUrlInfo.photocontentid forKey:@"photocontentid"];
        [dict setValue:baesUrlInfo.videocontentid forKey:@"videocontentid"];
        [dict setValue:baesUrlInfo.termsofuse forKey:@"termsofuse"];

        
        return  [dict writeToFile:path atomically:YES];
        
    }
    @catch (NSException *exception)
    {
        NSLog(@" %@:saveAppSettings Exception : %@ ",[self class],exception.description);
    }
    @finally
    {
        
    }
}
+(BaseUrlModel *)getBaseUrlSetting{
    @try
    {
        NSString *path = [AppSetting getPlistPath];
        NSMutableDictionary *dict=[[NSMutableDictionary alloc]initWithContentsOfFile:path];
        if(dict == nil)
            dict=[[NSMutableDictionary alloc] init];
        
        NSLog(@"Get : %@ ",dict);
        BaseUrlModel *model=[[BaseUrlModel alloc] init];
        model.title=[dict valueForKey:@"title"];
        model.vortalCallLetters=[dict valueForKey:@"vortalCallLetters"];
        model.vortatStationId=[dict valueForKey:@"vortatStationId"];
        model.websiteUrl=[dict valueForKey:@"websiteUrl"];
        model.facebook=[dict valueForKey:@"facebook"];
        model.twitter=[dict valueForKey:@"twitter"];
        model.uploadurl=[dict valueForKey:@"uploadurl"];
        model.fgUrl=[dict valueForKey:@"fgUrl"];
        model.iosStreamUrl=[dict valueForKey:@"iosStreamUrl"];
        model.bannerGroupId=[dict valueForKey:@"bannerGroupId"];
        model.headerImage=[dict valueForKey:@"headerImage"];
        model.signupUrl=[dict valueForKey:@"signupUrl"];
        model.infoUrl=[dict valueForKey:@"infoUrl"];
        model.stationid=[dict valueForKey:@"stationid"];
        model.photocontentid=[dict valueForKey:@"photocontentid"];
        model.videocontentid=[dict valueForKey:@"videocontentid"];
        model.termsofuse=[dict valueForKey:@"termsofuse"];

        
        //NSLog(@" %@:getUserInfo: %@",[self class],dict);
        return model;
    }
    @catch (NSException *exception)
    {
        NSLog(@"%@:getUserInfo Exception : %@ ",[self class],exception.description);
    }
    @finally
    {
    }
}

+(void)setAlarm:(BOOL )status{
    NSString *path = [AppSetting plist_dict];
    NSMutableDictionary *plist_dict=[[NSMutableDictionary alloc]initWithContentsOfFile:path];
    
    if(plist_dict == nil)
    {
        plist_dict = [[NSMutableDictionary alloc] init];
    }
    
    [plist_dict setObject:[NSNumber numberWithBool:status] forKey:@"isAlarm"];
    [plist_dict writeToFile:path atomically:YES];

}
+(BOOL)isAlarm{
    NSString *path = [AppSetting plist_dict];
    NSMutableDictionary *plist_dict=[[NSMutableDictionary alloc]initWithContentsOfFile:path];
    
    BOOL myBool = [[plist_dict objectForKey:@"isAlarm"] boolValue];
    
    return myBool;

}

@end
