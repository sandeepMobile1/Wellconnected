//
//  BannerGroupInvocation.m
//  Radio
//
//  Created by Om Prakash on 20/08/14.
//  Copyright (c) 2014 Octal Info Solution. All rights reserved.
//

#import "BannerGroupInvocation.h"
#import "JSON.h"
#import "BaseUrlModel.h"


@implementation BannerGroupInvocation
-(void)invoke {
    
    [self get:[self body]];
}

-(NSString*)body {
    
    
     BaseUrlModel *model = (BaseUrlModel *)[AppSetting getBaseUrlSetting];
    
 //   NSString* urlString = @"http://derftghyu.itm-staging.com/custom_code/mobile_app_banner_delivery.php?bannerxgroupid=33496";
    
    NSString* urlString = model.bannerGroupId;
    
    NSLog(@"Banner Url = %@",urlString);
    
    return urlString;
}

-(BOOL)handleHttpOK:(NSMutableData *)data {
	
    NSString *resultString=[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    
    
    //   NSDictionary* resultsd = (NSDictionary*)[resultString  JSONValue];
    [self.delegate bannerGroupInvocationDidFinish:self withResults:resultString withError:nil];
    return YES;
}


-(BOOL)handleHttpError:(NSInteger)code {
    
    [self.delegate bannerGroupInvocationDidFinish:self
                                  withResults:nil
                                    withError:[NSError errorWithDomain:@"bannerUrlInvocationDidFinish"
                                                                  code:code userInfo:[NSDictionary dictionaryWithObject:@"Failed to fetch data."
                                                                                                                 forKey:@"error"]]];
    
	return YES;
}

@end
