//
//  UpLoadMediaInvocation.m
//  CINA FM
//
//  Created by Om Prakash on 22/08/14.
//  Copyright (c) 2014 Octal Info Solution. All rights reserved.
//

#import "UpLoadMediaInvocation.h"
#import "BaseUrlModel.h"

@implementation UpLoadMediaInvocation
@synthesize media_data;
@synthesize form_field;
@synthesize u_url;

-(void)invoke {
    
    NSLog(@"Url = %@",self.u_url);
    
    [self executeBinary:@"POST" withUrl:self.u_url dict:self.form_field attachment:self.media_data];

    
}

-(NSString*)body
{
    NSMutableDictionary* bodyD = [[NSMutableDictionary alloc] init];
    
    return [bodyD JSONRepresentation];
}

-(BOOL)handleHttpOK:(NSMutableData *)data {
    
    NSString *resultString=[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
     // NSLog(@"regst \n= %@",resultString);
  //  NSDictionary* resultsd = (NSDictionary*)[resultString  JSONValue];
    
    [self.delegate upLoadMediaInvocationDidFinish:self withResults:resultString withError:nil];
    return YES;
}

-(BOOL)handleHttpError:(NSInteger)code {
    
    [self.delegate upLoadMediaInvocationDidFinish:self withResults:nil withError:[NSError errorWithDomain:@"uploadMediaInvocationDidFinish" code:code userInfo:[NSDictionary dictionaryWithObject:@"Failed .Please try again later." forKey:@"error"]]];
    
	return YES;
}


@end
