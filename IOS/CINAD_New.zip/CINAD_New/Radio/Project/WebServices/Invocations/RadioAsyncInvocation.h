//
//  RadioAsyncInvocation.h
//  Radio
//
//  Created by Om Prakash on 19/08/14.
//  Copyright (c) 2014 Octal Info Solution. All rights reserved.
//

#import "SAServiceAsyncInvocation.h"

@interface RadioAsyncInvocation : SAServiceAsyncInvocation

@end
