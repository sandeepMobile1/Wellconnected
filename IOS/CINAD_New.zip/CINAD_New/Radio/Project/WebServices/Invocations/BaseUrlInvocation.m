//
//  BaseUrlInvocation.m
//  Radio
//
//  Created by Om Prakash on 19/08/14.
//  Copyright (c) 2014 Octal Info Solution. All rights reserved.
//

#import "BaseUrlInvocation.h"
#import "JSON.h"

@implementation BaseUrlInvocation
-(void)invoke {
    
    [self get:[self body]];
}

-(NSString*)body {
    
    
    NSString* urlString = @"http://vortalobjects.secureitm.com/image/cinad/mobile_xml/cinad.xml";
    
    return urlString;
}

-(BOOL)handleHttpOK:(NSMutableData *)data {
	
    NSString *resultString=[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
    

 //   NSDictionary* resultsd = (NSDictionary*)[resultString  JSONValue];
    [self.delegate baseUrlInvocationDidFinish:self withResults:resultString withError:nil];
    return YES;
}


-(BOOL)handleHttpError:(NSInteger)code {
    
    [self.delegate baseUrlInvocationDidFinish:self
                                withResults:nil
                                  withError:[NSError errorWithDomain:@"baseUrlInvocationDidFinish"
                                                                code:code userInfo:[NSDictionary dictionaryWithObject:@"Failed to fetch data."
                                                                                                               forKey:@"error"]]];
    
	return YES;
}

@end
