//
//  BaseUrlInvocation.h
//  Radio
//
//  Created by Om Prakash on 19/08/14.
//  Copyright (c) 2014 Octal Info Solution. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SAServiceAsyncInvocation.h"
#import "RadioAsyncInvocation.h"
#import "SAService.h"

@class BaseUrlInvocation;

@protocol BaseUrlInvocationDelegate


-(void)baseUrlInvocationDidFinish:(BaseUrlInvocation*)invocation
                    withResults:(NSString*)result
                      withError:(NSError*)error;

@end

@interface BaseUrlInvocation : RadioAsyncInvocation{
    
}

@end
