//
//  WebService.h
//  Radio
//
//  Created by Om Prakash on 19/08/14.
//  Copyright (c) 2014 Octal Info Solution. All rights reserved.
//

#import "SAService.h"
#import "BaseUrlInvocation.h"
#import "BannerGroupInvocation.h"
#import "UpLoadMediaInvocation.h"


@interface WebService : SAService{
    
}
+(WebService*)sharedWebService;

-(void)baseUrlRequest:(id<BaseUrlInvocationDelegate>)delegate;
-(void)BannerGroupUrlRequest:(id<BannerGroupInvocationDelegate>)delegate;

-(void)uploadMediaInvocationWithURL:(NSString *)url  dict:(NSMutableDictionary *)dict MediaData:(NSData *)media_data delgate:(id<UpLoadMediaInvocationDelegate>)delegate;
@end
