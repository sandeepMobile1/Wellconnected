//
//  BannerGroupInvocation.h
//  Radio
//
//  Created by Om Prakash on 20/08/14.
//  Copyright (c) 2014 Octal Info Solution. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SAServiceAsyncInvocation.h"
#import "RadioAsyncInvocation.h"
#import "SAService.h"

@class BannerGroupInvocation;

@protocol BannerGroupInvocationDelegate


-(void)bannerGroupInvocationDidFinish:(BannerGroupInvocation*)invocation
                      withResults:(NSString*)result
                        withError:(NSError*)error;

@end

@interface BannerGroupInvocation : RadioAsyncInvocation{
    
}


@end
