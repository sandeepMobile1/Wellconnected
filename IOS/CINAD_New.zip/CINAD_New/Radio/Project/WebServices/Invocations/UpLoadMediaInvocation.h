//
//  UpLoadMediaInvocation.h
//  CINA FM
//
//  Created by Om Prakash on 22/08/14.
//  Copyright (c) 2014 Octal Info Solution. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SAServiceAsyncInvocation.h"
#import "RadioAsyncInvocation.h"
#import "SAService.h"

@class UpLoadMediaInvocation;

@protocol UpLoadMediaInvocationDelegate


-(void)upLoadMediaInvocationDidFinish:(UpLoadMediaInvocation*)invocation
                          withResults:(NSString*)result
                            withError:(NSError*)error;

@end


@interface UpLoadMediaInvocation : RadioAsyncInvocation{
    
}

@property (nonatomic, retain)NSData *media_data;
@property(nonatomic, strong)NSMutableDictionary *form_field;
@property (nonatomic, strong)NSString *u_url;

@end
