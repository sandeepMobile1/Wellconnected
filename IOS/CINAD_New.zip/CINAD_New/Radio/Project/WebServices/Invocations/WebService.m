//
//  WebService.m
//  Radio
//
//  Created by Om Prakash on 19/08/14.
//  Copyright (c) 2014 Octal Info Solution. All rights reserved.
//

#import "WebService.h"

static WebService *sharedWebService = nil;

@implementation WebService

+(WebService*)sharedWebService {
    
    @synchronized([WebService class])
    {
        if (!sharedWebService)
        {
            NSLog(@"------WebService Object created Shared--------");
            sharedWebService=[[self alloc] init];
        }
        return sharedWebService;
    }
    return nil;
}

-(void)baseUrlRequest:(id<BaseUrlInvocationDelegate>)delegate{
    BaseUrlInvocation *invocation=[[BaseUrlInvocation alloc] init];
    [self invoke:invocation withDelegate:delegate];
}

-(void)BannerGroupUrlRequest:(id<BannerGroupInvocationDelegate>)delegate{
    BannerGroupInvocation *invocation=[[BannerGroupInvocation alloc] init];
    [self invoke:invocation withDelegate:delegate];
}


-(void)uploadMediaInvocationWithURL:(NSString *)url  dict:(NSMutableDictionary *)dict MediaData:(NSData *)media_data delgate:(id<UpLoadMediaInvocationDelegate>)delegate{
    
    UpLoadMediaInvocation *invocation=[[UpLoadMediaInvocation alloc] init];
    invocation.media_data = media_data;
    invocation.form_field = dict;
    invocation.u_url = url ;
    [self invoke:invocation withDelegate:delegate];
}

@end
