//
//  RadioAsyncInvocation.m
//  Radio
//
//  Created by Om Prakash on 19/08/14.
//  Copyright (c) 2014 Octal Info Solution. All rights reserved.
//

#import "RadioAsyncInvocation.h"

@implementation RadioAsyncInvocation
-(id)init {
	self = [super init];
	if (self) {
		self.clientVersion = [[[NSBundle mainBundle] infoDictionary] objectForKey:(NSString*)kCFBundleVersionKey];
		self.clientVersionHeaderName = @"ProductStore-Client-Version";
	}
	return self;
}
@end
