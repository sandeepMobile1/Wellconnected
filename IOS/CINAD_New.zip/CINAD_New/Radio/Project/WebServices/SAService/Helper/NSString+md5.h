@interface NSString (md5)
	
+ (NSString *) md5:(NSString *)str;
	
@end
