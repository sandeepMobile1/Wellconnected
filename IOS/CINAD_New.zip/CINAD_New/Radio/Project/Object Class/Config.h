//
//  Config.h
//  Axess
//
//  Created by Pramod Sharma on 11/12/13.
//  Copyright (c) 2013 Octal Info Solution. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Config : NSObject

extern NSString *WebserviceUrl;
extern NSString *device_token;





@end
