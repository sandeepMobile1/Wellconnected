//
//  AppConstant.h
//  SnagFu
//
//  Created by octal i-phone2 on 7/15/13.
//  Copyright (c) 2014 __MyCompanyName__. All rights reserved.
//
#import "AppDelegate.h"
#import "Reachability.h"

#ifndef SnagFu_AppConstant_h
#define SnagFu_AppConstant_h

#define GEORGIAFONT @"Georgia"
#define ARIALFONT @"Arial"
#define ARIALFONT_BOLD @"Arial-BoldMT"

#define APPFONT @"HelveticaNeue"
#define TitleFontStyle @"Arial-BoldMT"


#define CREDIT_REMAINING @"creadit_remaining"


#define IS_DEVICE_IPAD                          ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)
#define DEVICE_OS_VERSION                       [[[UIDevice currentDevice] systemVersion] floatValue]
#define IS_IPHONE_5                              ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone && [UIScreen mainScreen].bounds.size.height == 568)

#define  IPHONE_FIVE_FACTOR 88
#define  IPHONE_FIVE_HEIGHT 568
#define  IPHONE_FOUR_HEIGHT 480

#define SYSTEM_VERSION_EQUAL_TO(v)                  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedSame)
#define SYSTEM_VERSION_GREATER_THAN(v)              ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedDescending)
#define SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(v)  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN(v)                 ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN_OR_EQUAL_TO(v)     ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedDescending)

#define NULL_TO_NIL(obj)                ({ __typeof__ (obj) __obj = (obj); __obj == [NSNull null] ? nil : obj; })

#define MoreNavColor              [UIColor colorWithRed:27/255.0 green:27/255.0 blue:27/255.0 alpha:1.0]  // [UIColor colorWithRed:68/255.0 green:136/255.0 blue:193/255.0 alpha:1.0]

#define StreetNavColor              [UIColor colorWithRed:27/255.0 green:27/255.0 blue:27/255.0 alpha:1.0]



inline static BOOL isInternetAvailable()
{
    if([[Reachability reachabilityWithHostname:@"www.google.com"] isReachable]){
        return YES;
    }
    else {
        return NO;
    }
}


inline static NSString *returnCurrentDate(){
    
    NSDate *date = [NSDate date];
    
    NSDateFormatter *shortFormat = [[NSDateFormatter alloc] init];
    [shortFormat setDateFormat:@"MM-dd-yyyy HH:mm"];
    NSString *return_date = [shortFormat stringFromDate:date];
    
    return  return_date;
}


inline static NSString *decodeFromPercentEscapeString(NSString *string)  {
    return (__bridge NSString *) CFURLCreateStringByReplacingPercentEscapesUsingEncoding(NULL,
                                                                                         (__bridge CFStringRef) string,
                                                                                         CFSTR(""),
                                                                                         kCFStringEncodingUTF8);
}

inline static void showInternetAlertMessage()
{
    UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"Internet" message:@"No Internet Connection available please connect to internet"
                                                 delegate:nil
                                        cancelButtonTitle:nil
                                        otherButtonTitles:@"OK",nil];
    [alert show];
}

inline static UIFont* getFont(float fontSize) {
    
    return [UIFont fontWithName:APPFONT size:fontSize];
}


inline static BOOL validateEmail(NSString *emailID)
{
    BOOL stricterFilter = YES; // Discussion http://blog.logichigh.com/2010/09/02/validating-an-e-mail-address/
    NSString *stricterFilterString = @"[A-Z0-9a-z\\._%+-]+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2,4}";
    NSString *laxString = @".+@([A-Za-z0-9]+\\.)+[A-Za-z]{2}[A-Za-z]*";
    NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:emailID];
}

inline static UIButton *getButtonImage(CGRect frame, NSString *imgName, id target, SEL action)
{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.frame = frame;
    [button setImage:[UIImage imageNamed:imgName] forState:UIControlStateNormal];
    [button addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
    return button;
}

inline static UIAlertView *getAlertView(NSString *title,NSString *msg,id delegate)
{
    UIAlertView *successAlert = [[UIAlertView alloc] initWithTitle:title message:msg  delegate:delegate cancelButtonTitle:nil otherButtonTitles:NSLocalizedString(@"OK", nil), nil];
    return successAlert;
}


inline static UILabel *getLabel(CGRect frame, NSString *text, UIColor *color, NSString *fontName, int fontSize)
{
    UILabel *label = [[UILabel alloc] initWithFrame:frame];
    label.text = [text capitalizedString];
    label.textColor = color;
    [label setFont:[UIFont fontWithName:fontName size:fontSize]];
    label.backgroundColor = [UIColor clearColor];
    label.textAlignment = NSTextAlignmentCenter;
    
    return label;
}


inline static CGFloat getLabelHeightForFont(NSString *fontName,NSString* str, float fontSize, float lblWidth)
{
    UIFont *font = [UIFont fontWithName:fontName size:fontSize];
    CGFloat height;

    CGSize maximumLabelSize = CGSizeMake(lblWidth,MAXFLOAT);
    CGSize expectedLabelSize = [str sizeWithFont:font
                                      constrainedToSize:maximumLabelSize
                                          lineBreakMode:NSLineBreakByWordWrapping];
    
    height = expectedLabelSize.height;
    return height;
}

enum DeviceType{
    kDeviceTypeiPhone=1,
    kDeviceTypeTalliPhone=2,
    kDeviceTypeiPad=3
};
inline static NSString * getStringAfterTriming(NSString *text)
{
    return [text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
}
#endif
