//
//  MoreTableViewCell.h
//  Radio
//
//  Created by Om Prakash on 20/08/14.
//  Copyright (c) 2014 Octal Info Solution. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MoreTableViewCell : UITableViewCell

@property(nonatomic, strong)IBOutlet UILabel     *lbl_title;
@property(nonatomic, strong)IBOutlet UIImageView *img_icon;
@property(nonatomic, strong)IBOutlet UIImageView *img_arrow;


@end
