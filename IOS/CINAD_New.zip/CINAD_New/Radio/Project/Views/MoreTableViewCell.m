//
//  MoreTableViewCell.m
//  Radio
//
//  Created by Om Prakash on 20/08/14.
//  Copyright (c) 2014 Octal Info Solution. All rights reserved.
//

#import "MoreTableViewCell.h"

@implementation MoreTableViewCell
@synthesize lbl_title;
@synthesize img_icon;
@synthesize img_arrow;

- (void)awakeFromNib
{
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
