//
//  Utils.h
//  UKAutorescue
//
//  Created by sandeep agrawal on 12/02/12.
//  Copyright (c) 2012 student.san1986@gmail.com. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Utils : NSObject{

}

+ (void) showAlertMessage:(NSString *)title Message:(NSString *)msg;

@end
