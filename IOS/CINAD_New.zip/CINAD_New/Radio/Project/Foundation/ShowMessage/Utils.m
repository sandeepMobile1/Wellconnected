//
//  Utils.m
//  UKAutorescue
//
//  Created by sandeep agrawal on 12/02/12.
//  Copyright (c) 2012 student.san1986@gmail.com. All rights reserved.
//

#import "Utils.h"

@implementation Utils

+ (void) showAlertMessage:(NSString *)title Message:(NSString *)msg {
	
	UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:msg delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
	[alert show];
	
}

@end
