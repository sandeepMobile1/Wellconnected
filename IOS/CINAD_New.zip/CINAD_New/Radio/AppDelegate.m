//
//  AppDelegate.m
//  Radio
//
//  Created by Om Prakash on 18/08/14.
//  Copyright (c) 2014 Octal Info Solution. All rights reserved.
//

#import "AppDelegate.h"
#import "TBXML.h"
#import "BaseUrlModel.h"
#import <NewRelicAgent/NewRelic.h>

@implementation AppDelegate
@synthesize nav,radio;
@synthesize appType;
@synthesize allarm;
@synthesize twitter;
@synthesize facebook;
@synthesize more;
@synthesize viewToolBarBase;
@synthesize tabBarController;
@synthesize navigationClassReference;

+(AppDelegate *)sharedAppDelegate{
    return (AppDelegate *)[[UIApplication sharedApplication] delegate];
}

void UncaughtExceptionHandler(NSException *exception)
{
    
    NSLog(@"@@@@@@@@@@@@@     \"\" UncaughtExceptionHandler\"\"       @@@@@@@@@@@");
    NSLog(@"%@",[exception description]);
    NSLog(@"%@",[exception callStackSymbols]);
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    
    [NewRelicAgent startWithApplicationToken:@"AA86187571d794fc12f42f5bbe4baf4563a7156978"];
    
    
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    // Override point for customization after application launch.
    
    counterTask = [[UIApplication sharedApplication]beginBackgroundTaskWithExpirationHandler:^{ }];
    
    NSSetUncaughtExceptionHandler(&UncaughtExceptionHandler );

    
    UILocalNotification *locationNotification = [launchOptions objectForKey:UIApplicationLaunchOptionsLocalNotificationKey];
    if (locationNotification) {
        // Set icon badge number to zero
        application.applicationIconBadgeNumber = 0;
    }
    
    
    if([UIDevice currentDevice].userInterfaceIdiom==UIUserInterfaceIdiomPhone)
    {          // iPhone and iPod touch style UI
        if([UIDevice currentDevice].userInterfaceIdiom==UIUserInterfaceIdiomPhone && [UIScreen mainScreen].bounds.size.height == 568)
        {          // iPhone and iPod touch style UI
            self.appType=kDeviceTypeTalliPhone;
        }
        else{
            self.appType=kDeviceTypeiPhone;
        }
    }
    else
    {
        self.appType=kDeviceTypeiPad;
    }

    [self createTabBar];
    
    self.window.backgroundColor = [UIColor whiteColor];
    [self.window makeKeyAndVisible];
    return YES;
}

- (void)application:(UIApplication *)application didReceiveLocalNotification:(UILocalNotification *)notification
{
    UIApplicationState state = [application applicationState];
    if (state == UIApplicationStateActive) {
        
        if([AppSetting isAlarm]){
            [[NSNotificationCenter defaultCenter] postNotificationName:@"play_fm" object:nil];
        }
        else{
            
        }
    }
    else{
        
    }

    application.applicationIconBadgeNumber = 0;
}

-(void)createTabBar{
    [self.viewToolBarBase removeFromSuperview];
    
    if (self.tabBarController!=nil){
        self.tabBarController=nil;
    }
    
    if (self.viewToolBarBase) {
        self.viewToolBarBase=nil;
    }
    
    if (self.appType==kDeviceTypeTalliPhone){
        self.viewToolBarBase=[[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 480+IPHONE_FIVE_FACTOR)];
    }
    else{
        self.viewToolBarBase=[[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 480)];
    }

    self.viewToolBarBase.backgroundColor=[UIColor clearColor];
    [_window addSubview:self.viewToolBarBase];
    
    self.tabBarController = [[UITabBarController alloc] init];
   // [self.tabBarController.tabBar setBackgroundImage:[UIImage imageNamed:@"bottom_bar.png"]];
    [self.tabBarController.tabBar setBackgroundColor:[UIColor blackColor]];
    
    
    
    self.radio=[[RadioViewController alloc] init] ;
    UINavigationController *navigationRadio=[[UINavigationController alloc] initWithRootViewController:self.radio];
    
    self.allarm=[[AllarmViewController alloc] init] ;
    UINavigationController *navigationAllarm=[[UINavigationController alloc] initWithRootViewController:self.allarm];
    
    self.facebook=[[FacebookViewController alloc] init] ;
    UINavigationController *navigationFacebook=[[UINavigationController alloc] initWithRootViewController:self.facebook];
    
    self.twitter=[[TwitterViewController alloc] init] ;
    UINavigationController *navigationTwirter=[[UINavigationController alloc] initWithRootViewController:self.twitter];
    
    self.more=[[MoreViewController alloc] init] ;
    UINavigationController *navigationMore=[[UINavigationController alloc] initWithRootViewController:self.more];
    
    NSMutableArray *arr_Controller=[[NSMutableArray alloc] init];
    [arr_Controller addObject:navigationRadio];
    [arr_Controller addObject:navigationAllarm];
    [arr_Controller addObject:navigationFacebook];
    [arr_Controller addObject:navigationTwirter];
    [arr_Controller addObject:navigationMore];
    
    //setting tab bar
    self.tabBarController.viewControllers =arr_Controller;
    self.tabBarController.view.hidden = NO;
    
    UITabBar *tabBar = self.tabBarController.tabBar;
    
    UITabBarItem *item0 = [tabBar.items objectAtIndex:0];
    [item0 setTitle:@""];
    UITabBarItem *item1 = [tabBar.items objectAtIndex:1];
    [item1 setTitle:@""];
    UITabBarItem *item2 = [tabBar.items objectAtIndex:2];
    [item2 setTitle:@""];
    UITabBarItem *item3 = [tabBar.items objectAtIndex:3];
    [item3 setTitle:@""];
    UITabBarItem *item4 = [tabBar.items objectAtIndex:4];
    [item4 setTitle:@""];
    
    if (self.appType==kDeviceTypeTalliPhone)
        self.tabBarController.tabBar.frame = CGRectMake(0, 430+IPHONE_FIVE_FACTOR, 320, 50);
    
    else
        self.tabBarController.tabBar.frame = CGRectMake(0, 430, 320, 50);
    
 //   [[UITabBar appearance] setSelectionIndicatorImage:[UIImage imageNamed:@"selection.png"]];
    [[UITabBar appearance]setSelectedImageTintColor:[UIColor redColor]];
    
    
    btn_listen = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn_listen addTarget:self action:@selector(btnListenPressed:) forControlEvents:UIControlEventTouchUpInside];
    CGRect btn_listenframe;
    btn_listenframe.size.height = 50;
    btn_listenframe.size.width = 64;
    btn_listenframe.origin.x = 0;
    btn_listenframe.origin.y = 0;
    [btn_listen setFrame:btn_listenframe];
    [btn_listen setBackgroundImage:[UIImage imageNamed:@"listen.png"] forState:UIControlStateNormal];
        [[tabBarController tabBar] addSubview:btn_listen];
    
    btn_alarm = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn_alarm addTarget:self action:@selector(btnAlarmPressed:) forControlEvents:UIControlEventTouchUpInside];
    CGRect frame;
    frame.size.height = 50;
    frame.size.width = 64;
    frame.origin.x = 64;
    frame.origin.y = 0;
    [btn_alarm setFrame:frame];
    [btn_alarm setBackgroundImage:[UIImage imageNamed:@"alarm.png"] forState:UIControlStateNormal];
    [[tabBarController tabBar] addSubview:btn_alarm];
    
    btn_facebook = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn_facebook addTarget:self action:@selector(btnFacebookPressed:) forControlEvents:UIControlEventTouchUpInside];
        CGRect btn_facebookframe;
    btn_facebookframe.size.height = 50;
    btn_facebookframe.size.width = 64;
    btn_facebookframe.origin.x = 128;
    btn_facebookframe.origin.y = 0;
    [btn_facebook setFrame:btn_facebookframe];
    [btn_facebook setBackgroundImage:[UIImage imageNamed:@"facebook.png"] forState:UIControlStateNormal];
    [[tabBarController tabBar] addSubview:btn_facebook];
    
    btn_twitter = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn_twitter addTarget:self action:@selector(btnTwitterPressed:) forControlEvents:UIControlEventTouchUpInside];
    CGRect btn_twitterframe;
    btn_twitterframe.size.height = 50;
    btn_twitterframe.size.width = 64;
    btn_twitterframe.origin.x = 192;
    btn_twitterframe.origin.y = 0;
    [btn_twitter setFrame:btn_twitterframe];
    [btn_twitter setBackgroundImage:[UIImage imageNamed:@"twitter.png"] forState:UIControlStateNormal];
    [[tabBarController tabBar] addSubview:btn_twitter];
    
    btn_more = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn_more addTarget:self action:@selector(btnMorePressed:) forControlEvents:UIControlEventTouchUpInside];
    CGRect btn_moreframe;
    btn_moreframe.size.height = 50;
    btn_moreframe.size.width = 64;
    btn_moreframe.origin.x = 256;
    btn_moreframe.origin.y = 0;
    [btn_more setFrame:btn_moreframe];
    [btn_more setBackgroundImage:[UIImage imageNamed:@"more.png"] forState:UIControlStateNormal];
    [[tabBarController tabBar] addSubview:btn_more];
    
    
    tabBarController.delegate = self;
    tabBarController.selectedIndex=0;
    [self.viewToolBarBase addSubview:tabBarController.view];
    
    [self btnListenPressed:self];
    
    
}

-(IBAction)btnListenPressed:(id)sender{
    [self.navigationClassReference popToRootViewControllerAnimated:NO];
    tabBarController.selectedIndex=0;
    [btn_listen setBackgroundImage:[UIImage imageNamed:@"listen_select.png"] forState:UIControlStateNormal];
    [btn_alarm setBackgroundImage:[UIImage imageNamed:@"alarm.png"] forState:UIControlStateNormal];
    [btn_facebook setBackgroundImage:[UIImage imageNamed:@"facebook.png"] forState:UIControlStateNormal];
    [btn_twitter setBackgroundImage:[UIImage imageNamed:@"twitter.png"] forState:UIControlStateNormal];
    [btn_more setBackgroundImage:[UIImage imageNamed:@"more.png"] forState:UIControlStateNormal];
}
-(IBAction)btnAlarmPressed:(id)sender{
    [self.navigationClassReference popToRootViewControllerAnimated:NO];
    tabBarController.selectedIndex=1;
    [btn_listen setBackgroundImage:[UIImage imageNamed:@"listen.png"] forState:UIControlStateNormal];
    [btn_alarm setBackgroundImage:[UIImage imageNamed:@"alarm_select.png"] forState:UIControlStateNormal];
    [btn_facebook setBackgroundImage:[UIImage imageNamed:@"facebook.png"] forState:UIControlStateNormal];
    [btn_twitter setBackgroundImage:[UIImage imageNamed:@"twitter.png"] forState:UIControlStateNormal];
    [btn_more setBackgroundImage:[UIImage imageNamed:@"more.png"] forState:UIControlStateNormal];
}
-(IBAction)btnFacebookPressed:(id)sender{
    [self.navigationClassReference popToRootViewControllerAnimated:NO];
    tabBarController.selectedIndex=2;
    [btn_listen setBackgroundImage:[UIImage imageNamed:@"listen.png"] forState:UIControlStateNormal];
    [btn_alarm setBackgroundImage:[UIImage imageNamed:@"alarm.png"] forState:UIControlStateNormal];
    [btn_facebook setBackgroundImage:[UIImage imageNamed:@"facebook_select.png"] forState:UIControlStateNormal];
    [btn_twitter setBackgroundImage:[UIImage imageNamed:@"twitter.png"] forState:UIControlStateNormal];
    [btn_more setBackgroundImage:[UIImage imageNamed:@"more.png"] forState:UIControlStateNormal];
}
-(IBAction)btnTwitterPressed:(id)sender{
    [self.navigationClassReference popToRootViewControllerAnimated:NO];
    tabBarController.selectedIndex=3;
    [btn_listen setBackgroundImage:[UIImage imageNamed:@"listen.png"] forState:UIControlStateNormal];
    [btn_alarm setBackgroundImage:[UIImage imageNamed:@"alarm.png"] forState:UIControlStateNormal];
    [btn_facebook setBackgroundImage:[UIImage imageNamed:@"facebook.png"] forState:UIControlStateNormal];
    [btn_twitter setBackgroundImage:[UIImage imageNamed:@"twitter_select.png"] forState:UIControlStateNormal];
    [btn_more setBackgroundImage:[UIImage imageNamed:@"more.png"] forState:UIControlStateNormal];
}
-(IBAction)btnMorePressed:(id)sender{
    [self.navigationClassReference popToRootViewControllerAnimated:NO];
    tabBarController.selectedIndex=4;
    [btn_listen setBackgroundImage:[UIImage imageNamed:@"listen.png"] forState:UIControlStateNormal];
    [btn_alarm setBackgroundImage:[UIImage imageNamed:@"alarm.png"] forState:UIControlStateNormal];
    [btn_facebook setBackgroundImage:[UIImage imageNamed:@"facebook.png"] forState:UIControlStateNormal];
    [btn_twitter setBackgroundImage:[UIImage imageNamed:@"twitter.png"] forState:UIControlStateNormal];
    [btn_more setBackgroundImage:[UIImage imageNamed:@"more_select.png"] forState:UIControlStateNormal];
}
-(void)removeTabBar{
    [self.viewToolBarBase removeFromSuperview];

}






- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    
    
    
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
