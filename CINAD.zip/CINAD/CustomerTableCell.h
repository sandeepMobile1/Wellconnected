//
//  CustomerTableCell.h
//  WCHL
//
//  Created by John Smith on 10/3/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

 

@interface CustomerTableCell : TTTableSubtitleItemCell

@end
