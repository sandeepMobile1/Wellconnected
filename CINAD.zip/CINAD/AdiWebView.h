@interface AdiWebView : TTWebController 
 
 
@end
