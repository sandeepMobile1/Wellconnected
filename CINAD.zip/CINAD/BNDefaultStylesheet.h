
@interface BNDefaultStyleSheet : TTDefaultStyleSheet

@end
