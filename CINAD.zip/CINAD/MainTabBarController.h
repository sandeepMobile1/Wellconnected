

@interface MainTabBarController : UITabBarController<UITabBarDelegate, UITabBarControllerDelegate, UINavigationControllerDelegate>

@end
