//
//  SettingsViewController_iPhone.h
//  Sunrise Alarm
//
//  Created by finucane on 8/21/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SettingsViewController.h"

@interface SettingsViewController_iPhone : SettingsViewController
{
    
}

@end
