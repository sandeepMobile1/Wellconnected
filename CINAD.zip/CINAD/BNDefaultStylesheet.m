#import "BNDefaultStyleSheet.h"


///////////////////////////////////////////////////////////////////////////////////////////////////

@implementation BNDefaultStyleSheet


- (UIColor*) navigationBarTintColor {
	return [UIColor blackColor];
}



@end