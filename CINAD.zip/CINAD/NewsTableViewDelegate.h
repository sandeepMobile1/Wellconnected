#import "Three20/Three20.h"
#import "NewsDetail.h"
 
@interface NewsTableViewDelegate : TTTableViewDragRefreshDelegate 
	

@end
