//
//  SnoozeViewController.h
//  Sunrise Alarm
//
//  Created by finucane on 7/21/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Settings.h"

@interface SnoozeViewController : UITableViewController
{
  Settings*settings;
}

@end
