//
//  TTWebViewController.h
//  WCHL
//
//  Created by joseph on 3/22/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TTWebViewController : TTWebController
{
    NSString *flag;
}

@property(nonatomic,retain)  NSString *flag;
@end
