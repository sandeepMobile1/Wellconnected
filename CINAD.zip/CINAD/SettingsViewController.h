//
//  SettingsViewController.h
//  Sunrise Alarm
//
//  Created by finucane on 8/23/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//
// #import <UIKit/UIKit.h>

#import "SettingsTableViewController.h"
#import "TimeViewController.h"

@interface SettingsViewController : UINavigationController
{
}

@property (nonatomic, retain) SettingsTableViewController*settingsTableViewController;
 
@end
